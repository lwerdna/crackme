#define _WIN32_WINNT 0x0502
#include <windows.h>
#include "myresource.h"

char OkMsg[] = {  'W'^0x7F, 'I'^0x7F, 'N'^0x7F, 'N'^0x7F, 'E'^0x7F, 'R'^0x7F, 0^0x7F };
char BadMsg[] = { 'N'^0x7F, 'O'^0x7F, 'P'^0x7F, 'E'^0x7F, 0^0x7F, 0^0x7F, 0^0x7F };

char * g_pMessage = OkMsg;

void mycrypt(char * where, char len)
    { while(len--) *where++ ^= 0x7F; }

BOOL mystrcmp(char * here, char * there)
{
    while(*here && *there && (*here++ == *there++)) {}  // equate until null encountered
    return (!*here && !*there);                         // return if both reached null
}

BOOL CheckSerial(char * serial)
{
    char serial1[8] = {  '8'^0x7F, '2'^0x7F, '7'^0x7F, '2'^0x7F, '3'^0x7F, '8'^0x7F, '6'^0x7F, 0 };

    mycrypt(serial1, 7);
    if(mystrcmp(serial1, serial))
        return 1;
    mycrypt(serial1, 7);

    return 0;
}


BOOL CALLBACK MyDialogProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam) {
    BOOL    bProcessedMessage = TRUE;

    switch(Message) {
            case WM_INITDIALOG:
                SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(NULL, IDI_WARNING));
                SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(NULL, IDI_WARNING));
                bProcessedMessage=TRUE;
                break;
            case WM_CLOSE:
                EndDialog(hWnd, IDOK);
                break;
            case WM_COMMAND:
                switch(LOWORD(wParam)) {
                    case ID_BUTTON1: {
                            char serial[32], i, *msg;
                            GetDlgItemText(hWnd, ID_EDIT2, serial, 32);
                            if(CheckSerial(serial))
                                msg = OkMsg;
                            else
                                msg = BadMsg;
                            
                            mycrypt(msg, 7);
                            MessageBoxA(NULL, msg, msg, MB_OK);
                            mycrypt(msg, 7);
                        }
                        break;
                    default:
                        bProcessedMessage=FALSE;
                        break;
                }

            default:
                bProcessedMessage=FALSE;
                break;
    }

    return bProcessedMessage;
}

void MyEntry() {
    HMODULE hModule;
    GetModuleHandleEx(2, NULL, &hModule);
    DialogBox(hModule, MAKEINTRESOURCE(ID_DIALOG), NULL, MyDialogProc);
}
