#include <stdio.h>

// from misc.obj
extern __int64 HexDecode(char * s);
extern __int64 NameToInt64(char *n);

// from cryptoX.obj
extern int VerifySerial(unsigned __int64 name, unsigned __int64 serial);

int main(int ac, char **av)
{
    if(ac<2)
        return 0;

    __int64 name = NameToInt64(av[1]);
    __int64 serial = HexDecode(av[2]);

    if(VerifySerial(name, serial))
    {
        printf("1\n");
        return 1;
    }
    else
    {
        printf("0\n");
        return 0;
    }
}
