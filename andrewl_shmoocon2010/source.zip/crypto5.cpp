#define _WIN32_WINNT 0x0502
#include <windows.h>
#include "res_dialog.h"

BYTE colors_scroll[3] = {153,188,226};
BYTE colors_edits[3] = {153,188,226};

WCHAR strCrackmeInfo[] = L"<DECODING TRANSMISSION>\n"
                        L"\n"
                        L"Shmoocon 2010\n"
                    L"Crypto Challenge #5\n"
                    L"\"Half a key exchange, maybe..\"\n"
                    L"\n"
                    L"Difficulty: 3/9\n"
                    L"\n"
                    L"Example keys:\n" 
L"    Batou: 88529BF6A8CB14B5\n"
L"   Togusa: 36B41A787879ADD6\n"
L"  Aramaki: 477952210BB3023A\n"
L" Kusanagi: 31B14032F2B3D880\n"
                        L"\n"
                        L"<END OF TRANSMISSION>";

UINT64 f(UINT64 a, UINT64 b, UINT64 c)
{
    UINT64 j = 0;

    while(b)
    {
        if(a > c)
            a %= c;

        if(b & 1)
            j += a;
            
        while(j > c)
            j -= c;

        a <<= 1;
        b >>= 1;
    }

    return j;
}

UINT64 g(UINT64 a, UINT64 b, UINT64 c)
{
    UINT64 i = 1;
    UINT64 h = a;

    while(b)
    {
        if(b & 1)
            i = f(i, h, c);

        h = f(h, h, c);

        b >>= 1;
    }

    return i;
}

BOOL VerifySerial(UINT64 name, UINT64 serial)
{
    name = g(name, 1, 0xFFFFFFFB);

    UINT r = serial >> 32;
    UINT s = (UINT)serial;

    UINT64 result;
    result = g(s, 0xB00BEEE5, 0xFFFFFFFB);
    result = g(result, 0xFFFFFFF9, 0xFFFFFFFB);
    result = f(result, r, 0xFFFFFFFB);

    return (result == name);
}




