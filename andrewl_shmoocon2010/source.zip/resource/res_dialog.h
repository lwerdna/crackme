#define ID_DIALOG2 98
#define ID_DIALOG  99 

#define ID_BUTTON1  100
#define ID_BUTTON2  101
#define ID_BUTTON3  102
#define ID_BUTTON4  103

#define ID_EDIT1    104
#define ID_EDIT2    105
#define ID_BG       106

#define ID_LTEXT1   110
#define ID_LTEXT2   111

#define ID_FONT     120

#define ID_BMP1     130

