#include "funcrt.h"

// ----------------------------------------------------------------
//
// CONVERSION FUNCTIONS
//
// ----------------------------------------------------------------

__int64 HexDecode(char *s)
{
    __int64 x=0;

    unsigned char lookup[256];
    for(int i=0; i<256; ++i)
    {
        lookup[i]=0;
        if(i>='0' && i<='9')
            lookup[i] = i-'0';
        else if(i>='A' && i<='F')
            lookup[i] = i-'A'+10;
        else if(i>='a' && i<='f')
            lookup[i] = i-'a'+10;
    }

    while(*s)
    {
        x <<= 4;
        x |= lookup[*s++];
    }

    return x;
}

__int64 NameToInt64(char *n)
{
    char name_buff[32];
    memset(name_buff, 0, 32*sizeof(char));
    strcpy(name_buff, n);

    __int64 name=0;
    name ^= *(__int64 *)(name_buff + 0);
    name ^= *(__int64 *)(name_buff + 8);
    name ^= *(__int64 *)(name_buff + 16);
    name ^= *(__int64 *)(name_buff + 24);

    return name;
}
