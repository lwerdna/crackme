#define _WIN32_WINNT 0x0502
#include <windows.h>
#include "res_dialog.h"

BYTE colors_scroll[3] = {31,44,29};
BYTE colors_edits[3] = {179,201,173};

WCHAR strCrackmeInfo[] = L"<DECODING TRANSMISSION>\n"
                        L"\n"
                        L"Shmoocon 2010\n"
                        L"Crypto Challenge #3\n"
                    L"\"A familiar friend!\"\n"
                    L"\n"
                    L"Difficulty: 2/9\n"
                    L"\n"
                    L"Example keys:\n" 
L"    Batou: 18996B88816B9714\n"
L"   Togusa: 6E876F377892275E\n"
L"  Aramaki: 4B65C45BBDA370B8\n"
L" Kusanagi: 30F6E182CAA0DE3A\n"
                        L"\n"
                        L"<END OF TRANSMISSION>";

UINT64 g(UINT64 a, UINT64 b, UINT64 c)
{
    UINT64 j = 0;

    while(b)
    {
        while(a > c)
            a -= c;

        if(b & 1)
            j += a;
            
        while(j > c)
            j -= c;

        a <<= 1;
        b >>= 1;
    }

    return j;
}

UINT64 f(UINT64 a, UINT64 b, UINT64 c)
{
    UINT64 i = 1;
    UINT64 h = a;

    while(b)
    {
        if(b & 1)
            i = g(i, h, c);

        h = g(h, h, c);

        b >>= 1;
    }

    return i;
}

BOOL VerifySerial(UINT64 name, UINT64 serial)
{

    UINT64 result = f(serial, 0xDEADBEEF, 0x7FBF89F8CD4152C5);

    return (result == name);
}




