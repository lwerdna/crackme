#include <windows.h>
#include <stdio.h>

#define PRIMITIVE_POLY 0x80027

UINT64 FieldMul(UINT64 multiplicand, UINT64 multiplier, UINT64 modulus)
{
    UINT64 d_mask;
    UINT64 result;

    // measure the degree of the modulus
    d_mask = (UINT64)1 << 63;

    while(!(d_mask & modulus))
        d_mask >>= 1;

    // calculate the product
    result = 0;
        
    while(multiplier)
    {
        // if the current coeff of the muliplier is set
        //   then add the multiplicand to the result
        if(multiplier & 1)
            result ^= multiplicand;

        multiplier >>= 1;

        multiplicand <<= 1;

        // if degree(multiplicand) >= degree(modulus)
        //   then subtract the modulus
        if(multiplicand & d_mask)
            multiplicand ^= modulus;
    }

    return result;
}

UINT64 FieldAdd(UINT64 addend_a, UINT64 addend_b)
{
    return addend_a ^ addend_b;
}

UINT64 FieldPow(UINT64 base, UINT64 exp, UINT64 m)
{
    UINT64 result = 1;
    UINT64 runner = base;

    while(exp)
    {
        if(exp & 1)
            result = FieldMul(result, runner, m);

        runner = FieldMul(runner, runner, m);

        exp >>= 1;
    }

    return result;
}

UINT64 FieldDivide(UINT64 dividend, UINT64 divisor, UINT64 *remainder)
{
    UINT64 quotient = 0;

    // position the divisor all the way to the left of a 32-bit data type
    // count the degree of this divisor
    INT degree = 63;

    while(!(divisor & ((UINT64)1<<63)))
    {
        divisor <<= 1;
        degree--;
    }

    quotient = 0;

    for(INT bit = 63; bit >= degree; --bit)
    {
        if(dividend & ((UINT64)1<<bit))
        {
            quotient |= ((UINT64)1<<(bit-degree));

            dividend ^= divisor;
        }

        // slide the divisor to the right across the dividend
        divisor >>= 1;
    }

    *remainder = dividend;

    return quotient;
}

// purposely did not collapse this into a routine that swaps the a and b
// the code is a twice as long this way, but more than twice as clear
//
UINT64 FieldEGCD(UINT64 a, UINT64 b, UINT64 primitive, UINT64 *r, UINT64 *s)
{
    UINT64 sum;
    UINT64 product;
    UINT64 quotient;
    UINT64 remainder;

    // 
    UINT64 gcd = 0;

    // throughout the computation we'll keep track of the current a, b
    // expressed in terms of the original a and b
    UINT64 r_a = 1, s_a = 0; // a = 1*a + 0*b
    UINT64 r_b = 0, s_b = 1; // b = 0*b + 1*a

    while(a && b)
    {
        if(a > b)
        {
            quotient = FieldDivide(a, b, &remainder);
            a = remainder;

            // update the expression for a in terms of original a and b
            //
            product = FieldMul(quotient, r_b, primitive);
            r_a = FieldAdd(r_a, product);       // r_a = r_a - quotient * (r_b);

            product = FieldMul(quotient, s_b, primitive);
            s_a = FieldAdd(s_a, product);       // s_a = s_a - quotient * (s_b);
        }
        else
        {
            quotient = FieldDivide(b, a, &remainder);
            b = remainder;

            // update the expression for b in terms of original a and b
            //
            product = FieldMul(quotient, r_a, primitive);
            r_b = FieldAdd(r_b, product);       // r_a = r_a - quotient * (r_a);

            product = FieldMul(quotient, s_a, primitive);
            s_b = FieldAdd(s_b, product);       // s_b = s_b - quotient * (s_a);
        }
    }

    if(a)
    {
        *s = s_a;
        *r = r_a;
        return a;
    }
    else
    {
        *s = s_b;
        *r = r_b;
        return b;
    }
}

UINT64 FieldInvert(UINT64 a, UINT64 primitive)
{
    UINT64 r, s;

    FieldEGCD(a, primitive, primitive, &r, &s);

    return r;
}

UINT64 MulMod(UINT64 a, UINT64 b, UINT64 c)
{
    UINT64 result = 0;

    while(b)
    {
        if(a > c)
            a %= c;

        if(b & 1)
            result += a;
            
        while(result > c)
            result -= c;

        a <<= 1;
        b >>= 1;
    }

    return result;
}

UINT64 PowMod(UINT64 a, UINT64 p, UINT64 c)
{
    UINT64 result = 1;
    UINT64 runner = a;

    while(p)
    {
        if(p & 1)
            result = MulMod(result, runner, c);

        runner = MulMod(runner, runner, c);

        p >>= 1;
    }

    return result;
}

VOID Gen5(UINT64 name, PCHAR serial)
{
    name = PowMod(name, 1, 0xFFFFFFFB);

    UINT k = GetTickCount();
    UINT s = PowMod(31337, k, 0xFFFFFFFB); // half secret is g^k (private side will do s^x to get shared secret
    //printf("s:%u\n", s);

    UINT r = PowMod(31337, 0xB00BEEE5, 0xFFFFFFFB); // y = g^x
    //printf("r:%u\n", r);
    r = PowMod(r, k, 0xFFFFFFFB); // y^k = g^{xk}
    //printf("r:%u\n", r);
    r = MulMod(name, r, 0xFFFFFFFB); // m*y^k = g^{xk}
    //printf("r:%u\n", r);


    UINT64 iSerial = ((UINT64)r << 32) | s;

    // encode result base64
    DWORD dwRet=32;
    sprintf(serial, "%016I64X", iSerial);
}

VOID Gen4(UINT64 name, PCHAR serial)
{
    #define POLY_GEN4 0x17A6DC8D861

    name ^= 0xDEADBEEFCAFEBABE;

    // save top 40 bits of name
    name >>= 24;

    // field order 2^40 - 1
    // to invert x^257 we need 257^-1 (mod 2^40 - 1) = 551894941568
    UINT64 iSerial = FieldPow(name, 551894941568 , POLY_GEN4);

    // encode result base64
    DWORD dwRet=32;
    sprintf(serial, "%016I64X", iSerial);
}

VOID Gen3(UINT64 name, PCHAR serial)
{
/*
  p = 3035678903           B4F0C8B7
  q = 3032345699           B4BDEC63
  n = 9205227865057088197  7FBF89F8CD4152C5
phi = 9205227858989063596  7FBF89F763929DAC
  e = 3735928559           DEADBEEF
  d = 8179089884777476759  7181F6EA6026F297
*/
    UINT64 iSerial = PowMod(name, 0x7181F6EA6026F297, 0x7FBF89F8CD4152C5);

    // encode result base64
    DWORD dwRet=32;
    sprintf(serial, "%016I64X", iSerial);
}

VOID Gen2(UINT64 name, PCHAR serial)
{
/* notes:
(16:46) gp > p=lift(ffinit(2,63))
%8 = x^63 + x^61 + x^57 + x^56 + x^54 + x^51 + x^47 + x^46 + x^45 + x^44 + x^43 + x^42 + x^39 + x^38 + x^35 + x^34 + x^32 + x^31 +
 x^28 + x^25 + x^24 + x^23 + x^21 + x^19 + x^18 + x^17 + x^15 + x^13 + x^10 + x^8 + x^7 + x^5 + x^2 + x + 1

(16:46) gp > forstep(i=63,0,-1,print1(polcoeff(p,i)))
1010001101001000111111001100110110010011101011101010010110100111
*/

    UINT64 iSerial = FieldInvert(name, 0xA348FCCD93AEA5A7);

    // encode result base64
    DWORD dwRet=32;
    sprintf(serial, "%016I64X", iSerial);
}

VOID Gen1(UINT64 name, PCHAR serial)
{
    UINT64 result = 0;

    UINT64 v[64] = 
    {
        0x2B051C9C1EDDEB5E, 0xF209D41D4B91A48F, 0xDE73A93AC3F6DF9D, 0xC07A3007B2202D0D, 
        0x541699E674D814DC, 0x0CD9A7CFC9AA262B, 0xD87C446AA2D66D32, 0xDBA03E4468E5E93F, 
        0x9F992C58E22F5210, 0xD7D55CD22CB57E28, 0xA7136D15BC416356, 0x9E2CBBD1F081E18A, 
        0xCDF8EFBD20A280FE, 0x0495F4C541F36B7B, 0x7F551986BCA78B3C, 0xC88CC72C4CEBC9C3, 
        0xF043F3A9D7109E8B, 0x8C1E33BCACD7C7EC, 0xCCB15071F3D1A2F2, 0xEE8ABA649DA37E2B, 
        0x67D443418CE6A298, 0x935963238AE1AD5D, 0x65405794BDFED38F, 0x969BCEBCC35283B6, 
        0xF89D903CBE732560, 0x03D921006BA75FB3, 0xCDEA06A105245151, 0x542248B95A1EC4DB, 
        0x032ECB2055E7B340, 0x6598F2FAB41A569E, 0x2578B10523E5462D, 0xA221C85C29C9F931, 
        0xFAF6AB90759B09E3, 0xF51809545351F34D, 0xBE565CC2ED0EF44A, 0x50D1DE9AE06ACC8C, 
        0x6DA57822213CEBE5, 0x3E2FBBE3C55EF315, 0x1D83F99FEAFD00C0, 0x8207CF943EE95FDF, 
        0x1DACCCD74A51492E, 0x4EF40A456EF7397F, 0xFC90CC28A6A1DE79, 0x49BE6C9668DF3B40, 
        0x3C6CCCDB30879DE5, 0x04401289ADC4802A, 0xF65483CB8576F232, 0xE82293C84EAA56B3, 
        0x42A1859B1789C383, 0x0DD819A5C81F9830, 0xBDB17DF943478A68, 0xB67A21EE51FDBDFD, 
        0xF2EBA03237778286, 0x772AAEBD7736F7D2, 0xFF83477D2561513F, 0x369134B334BCC203, 
        0x5C6480BB06E12CE9, 0x216B927C41BD7340, 0xF895CC8FD29DF00E, 0x9E5E8CE4CCCE30FB, 
        0xC79FDA47AF55C62A, 0xE8AF359EB70BA995, 0xB1A4A0EA69A21F56, 0x977AB984A906B2BF
    };

    for(INT i=0; i<64; ++i)
    {
        UINT64 a = name & v[i];
        UINT64 b = 0;

        while(a)
        {
            b ^= (a & 1);
            a /= 2;
        }

        result |= (b << (63-i));
    }

    // encode result base64
    DWORD dwRet=32;
    sprintf(serial, "%016I64X", result);

}

INT main(INT ac, PCHAR * av)
{
    if(ac < 2)
        goto cleanup;

    CHAR name[33];
    CHAR serial[33];

    memset(name, 0, 33);
    if(strlen(av[1]) > 32)
        goto cleanup;

    strcpy(name, av[1]);

    // name to an int
    UINT64 iName = *(PUINT64)name;
    iName ^= *(PUINT64)(name+8);
    iName ^= *(PUINT64)(name+16);
    iName ^= *(PUINT64)(name+24); 

    //printf("iName: %016I64X\n", iName);

    Gen1(iName, serial);
    printf("for crypt1: %s\n", serial);

    Gen2(iName, serial);
    printf("for crypt2: %s\n", serial);

    Gen3(iName, serial);
    printf("for crypt3: %s\n", serial);

    Gen4(iName, serial);
    printf("for crypt4: %s\n", serial);

    Gen5(iName, serial);
    printf("for crypt5: %s\n", serial);

    PCHAR names[4]={"Batou", "Togusa", "Aramaki", "Kusanagi"};

    printf("Gen1:\n");
    for(INT i=0; i<4; ++i)
    {
        memset(name, 0, 33);
        strcpy(name, names[i]);

        iName = *(PUINT64)name;
        iName ^= *(PUINT64)(name+8);
        iName ^= *(PUINT64)(name+16);
        iName ^= *(PUINT64)(name+24); 

        Gen1(iName, serial);
        printf("L\"% 9s: %s\\n\"\n", names[i], serial);
    }

    printf("Gen2:\n");
    for(INT i=0; i<4; ++i)
    {
        memset(name, 0, 33);
        strcpy(name, names[i]);

        iName = *(PUINT64)name;
        iName ^= *(PUINT64)(name+8);
        iName ^= *(PUINT64)(name+16);
        iName ^= *(PUINT64)(name+24); 

        Gen2(iName, serial);
        printf("L\"% 9s: %s\\n\"\n", names[i], serial);
    }

    printf("Gen3:\n");
    for(INT i=0; i<4; ++i)
    {
        memset(name, 0, 33);
        strcpy(name, names[i]);

        iName = *(PUINT64)name;
        iName ^= *(PUINT64)(name+8);
        iName ^= *(PUINT64)(name+16);
        iName ^= *(PUINT64)(name+24); 

        Gen3(iName, serial);
        printf("L\"% 9s: %s\\n\"\n", names[i], serial);
    }

    printf("Gen4:\n");
    for(INT i=0; i<4; ++i)
    {
        memset(name, 0, 33);
        strcpy(name, names[i]);

        iName = *(PUINT64)name;
        iName ^= *(PUINT64)(name+8);
        iName ^= *(PUINT64)(name+16);
        iName ^= *(PUINT64)(name+24); 

        Gen4(iName, serial);
        printf("L\"% 9s: %s\\n\"\n", names[i], serial);
    }

    printf("Gen5:\n");
    for(INT i=0; i<4; ++i)
    {
        memset(name, 0, 33);
        strcpy(name, names[i]);

        iName = *(PUINT64)name;
        iName ^= *(PUINT64)(name+8);
        iName ^= *(PUINT64)(name+16);
        iName ^= *(PUINT64)(name+24); 

        Gen5(iName, serial);
        printf("L\"% 9s %s\\n\"\n", names[i], serial);
    }

    cleanup:
    return 0;
}
