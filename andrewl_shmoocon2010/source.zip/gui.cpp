// 2010 andrewl

#include <windows.h>
#include <ole2.h>

#include "res_dialog.h"

#include "gdiplus.h"
using namespace Gdiplus;

extern "C"
{
#include "ufmod.h"
}

#include "funcrt.h"

extern WCHAR strCrackmeInfo[];
extern BOOL VerifySerial(UINT64 name, UINT64 serial);

extern __int64 HexDecode(char * s);
extern __int64 NameToInt64(char *n);

extern BYTE colors_scroll[3];
extern BYTE colors_edits[3];

//
// globals
//
PWCHAR scroll_text = L"SHMOOCON 2010 - FEBRUARY 5TH-7TH - Washington DC, USA - EVENT: GHOST IN THE SHELLCODE - CHALLENGE TYPE: CRYPTO - ALL MEDIA COLLECTED ONLINE: MODARCHIVE, BIG CHIPCOMPO 4 VOTEDISK, DAFONT, IMAGES.GOOGLE - CODE BY ANDREWL/CRACKMES.DE - SPECIAL GREETS TO FELLOW MODS";
UINT n_scroll_text; // computed at runtime

UINT n_strCrackmeInfo;

HMODULE g_hModule;

// animation
INT text_x=0;

INT terminal_inc = 0;
INT terminal_amt = 0;

// global gdi/gdi+ crap
HRSRC hResFont;
HGLOBAL hMemFont;
PVOID pFontData;
UINT nFontData;
PrivateFontCollection * pFontColl;
FontFamily fontFam;
Font * fontCustom;
INT nFontsFound;
Font * fontLucCon;

HBRUSH black;
HBRUSH brushEdit;

Bitmap *bmpBG;

// shims to please compiler/linker
extern "C" int _fltused = 1;

//
// main crackme dialog callback
//
BOOL CALLBACK DlgProcGui(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
    RECT rect1, rect2;
    HRGN rgn=0;
    UINT xRes=0;
    UINT yRes=0;

    static RECT rectBG;
    static Rect *pClip1=0, *pClip2=0;

    PDRAWITEMSTRUCT pDIS=0;

    BOOL bProcessedMessage = FALSE;

    switch(Message) {
        case WM_CTLCOLORDLG:
            return (BOOL) black;

        case WM_CTLCOLORSTATIC:
            return FALSE;
            break;
            /*
            SetTextColor((HDC)wParam, RGB(0xFF, 0xFF, 0xFF));
            SetBkMode((HDC)wParam, TRANSPARENT);
            return (BOOL) black;
            */

       case WM_CTLCOLOREDIT:
            SetBkMode((HDC)wParam, TRANSPARENT);
            return (BOOL) brushEdit;

        case WM_INITDIALOG:
            SetWindowText(hWnd, "Shmoocon 2010 - Crypto Challenges");

            SetDlgItemText(hWnd, ID_EDIT1, "<name>");
            SetDlgItemText(hWnd, ID_EDIT2, "<serial>");

            SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon((HINSTANCE)g_hModule, MAKEINTRESOURCE(90)));
            SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon((HINSTANCE)g_hModule, MAKEINTRESOURCE(90)));

            // get the clipping regions (the coords of the EDIT's relative to the BG)
            //
            GetWindowRect(GetDlgItem(hWnd, ID_BG), &rect1);
            GetWindowRect(GetDlgItem(hWnd, ID_EDIT1), &rect2);
            pClip1 = new Rect(rect2.left - rect1.left, rect2.top - rect1.top, rect2.right - rect2.left, rect2.bottom-rect2.top);

            GetWindowRect(GetDlgItem(hWnd, ID_EDIT2), &rect2);
            pClip2 = new Rect(rect2.left - rect1.left, rect2.top - rect1.top, rect2.right - rect2.left, rect2.bottom-rect2.top);

            // pre-compute so WM_ONDRAW won't have to
            GetClientRect(GetDlgItem(hWnd, ID_BG), &rectBG); 

            // center us
            // get window size
            if(GetWindowRect(hWnd, &rect1))
            {
                rect1.right = rect1.right - rect1.left;
                rect1.bottom = rect1.bottom - rect1.top;

                // get screen size, reposition window
                xRes=GetDeviceCaps(GetDC(NULL), HORZRES);
                yRes=GetDeviceCaps(GetDC(NULL), VERTRES);
                SetWindowPos(hWnd, 0, (xRes-rect1.right)/2, (yRes-rect1.bottom)/2, rect1.right, rect1.bottom, SWP_SHOWWINDOW);

                // set rounded region
                rgn = CreateRoundRectRgn(0, 0, rect1.right, rect1.bottom, 16, 16);
                SetWindowRgn(hWnd, rgn, 1);

                SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
                SetLayeredWindowAttributes(hWnd, 0, 0xDDDDDD, LWA_ALPHA);
            }

            // make sure we're up top!
            SetForegroundWindow(hWnd);

            // set animation timer
            SetTimer(hWnd, 0, 10, 0); // ~ 16 times/sec

            return TRUE;
            break;

        case WM_TIMER:
            if(text_x < -4500)
                text_x=0;
            text_x -= 1;

            terminal_inc++;
            if(terminal_inc == 10)
            {
                terminal_inc=0;

                if(terminal_amt < n_strCrackmeInfo)
                    terminal_amt++;
            }

            InvalidateRect(GetDlgItem(hWnd, ID_BG), 0, 1);

            return TRUE;
            break;

        case WM_CLOSE:
            EndDialog(hWnd, IDOK);
            return TRUE;
            break;

        case WM_COMMAND:
            if(LOWORD(wParam) == IDCANCEL)
            {
                SendMessage(hWnd, WM_CLOSE, (WPARAM)0, (LPARAM)0);
                return TRUE;
                break;

            } 
            else if(HIWORD(wParam)==EN_CHANGE && (LOWORD(wParam)==ID_EDIT2 || LOWORD(wParam)==ID_EDIT1))
            {
                CHAR name[33];
                CHAR serial[33];
                memset(name, 0, 33);
                if(GetDlgItemText(hWnd, ID_EDIT1, name, 32) <= 1)
                    goto rejected;
                if(!GetDlgItemText(hWnd, ID_EDIT2, serial, 32))
                    goto rejected;

                UINT64 iName = NameToInt64(name);
                UINT64 iSerial = HexDecode(serial);

                if(VerifySerial(iName, iSerial))
                {
                    wcscpy(strCrackmeInfo, L"<DECODING TRANSMISSION>\n\nNice indeed. Everything's\naccounted for, except your\nold shell.\n\n<END TRANSMISSION>");
                    n_strCrackmeInfo = wcslen(strCrackmeInfo);
                    terminal_amt = 0;
                }

                rejected:
                return TRUE;
            }
            else
                return FALSE;

        case WM_LBUTTONDOWN:
            SendMessage(hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            return FALSE;

        case WM_DRAWITEM:
            pDIS = (PDRAWITEMSTRUCT) lParam;

            if(((PDRAWITEMSTRUCT)lParam)->CtlID == ID_BG)
            {
                Bitmap bmp(rectBG.right, rectBG.bottom);
                Graphics graphics(&bmp);

                graphics.Clear(Color(255,121,128,134));

                graphics.DrawImage(bmpBG, 0, 0);


                // draw vert scrolling barcode text
                SolidBrush brush(Color(148,colors_scroll[0],colors_scroll[1],colors_scroll[2]));

                graphics.RotateTransform(-90);
                graphics.DrawString(scroll_text, n_scroll_text, fontCustom, PointF((float)text_x, 118), &brush);

                // draw "terminal" text
                SolidBrush brush2(Color(255,255,255,255));

                graphics.ResetTransform();

                WCHAR temp = strCrackmeInfo[terminal_amt+1];
                strCrackmeInfo[terminal_amt+1] = GetTickCount() & 0xFF;
                if(terminal_amt == n_strCrackmeInfo)
                    strCrackmeInfo[terminal_amt+1] = L'\0';
                graphics.DrawString(strCrackmeInfo, terminal_amt+2, fontLucCon, PointF(6.0f, 12.0f), &brush2);
                strCrackmeInfo[terminal_amt+1] = temp;

                // transfer buffer
                Graphics graphics2(pDIS->hDC);
                graphics2.ExcludeClip(*pClip1);
                graphics2.ExcludeClip(*pClip2);
                graphics2.DrawImage(&bmp, 0, 0, rectBG.right, rectBG.bottom);

                return TRUE;
            }
            else
                return FALSE;

        default:
            return FALSE;
    }

    return bProcessedMessage;
}

VOID WINAPI MyWinMain()
{
    // set global module
    g_hModule = GetModuleHandle(0);

    // init custom CRT
    //
    crt_initialize();

    // init GDI+
    //
    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    black = CreateSolidBrush(RGB(0,0,0));
    brushEdit = CreateSolidBrush(RGB(colors_edits[0],colors_edits[1],colors_edits[2]));

    // load fonts
    hResFont = FindResource(g_hModule, MAKEINTRESOURCE(ID_FONT), "BINARY");
    hMemFont = LoadResource(g_hModule, hResFont);
    pFontData = LockResource(hMemFont);
    nFontData = SizeofResource(g_hModule, hResFont);
    pFontColl = new PrivateFontCollection();
    pFontColl->AddMemoryFont(pFontData, nFontData);
    pFontColl->GetFamilies(1, &fontFam, &nFontsFound);
    fontCustom = new Font(&fontFam, 96, FontStyleRegular, UnitPixel);
    fontCustom = new Font(&fontFam, 96, FontStyleRegular, UnitPixel);
    fontLucCon = new Font(L"Lucida Console", 8);

    // load images
    HRSRC hJPG = FindResource(g_hModule, MAKEINTRESOURCE(ID_BMP1), "BINARY");
    UINT nJPG = SizeofResource(g_hModule, hJPG);
    PVOID pJPG = LockResource(LoadResource(g_hModule, hJPG));
    HANDLE hBuffJPG = GlobalAlloc(GMEM_MOVEABLE, nJPG);
    PVOID pBuffJPG = GlobalLock(hBuffJPG);
    memcpy(pBuffJPG, pJPG, nJPG);
    IStream* pStream;
    CreateStreamOnHGlobal(hBuffJPG, 0, &pStream);
    bmpBG = Bitmap::FromStream(pStream);
    pStream->Release();

    // misc
    n_scroll_text = wcslen(scroll_text);
    n_strCrackmeInfo = wcslen(strCrackmeInfo);

    // music!
    uFMOD_PlaySong((PVOID)1010, g_hModule, XM_RESOURCE);

    // GUI!
    DialogBox((HINSTANCE)g_hModule, MAKEINTRESOURCE(ID_DIALOG), 0, DlgProcGui);

    // release GDI+
    GdiplusShutdown(gdiplusToken);

    // uninit CRT
    crt_uninitialize();

    ExitProcess(0);
}
