#define _WIN32_WINNT 0x0502
#include <windows.h>
#include "res_dialog.h"

BYTE colors_scroll[3] = {79,73,148};
BYTE colors_edits[3] = {152,148,201};

WCHAR strCrackmeInfo[] =  L"<DECODING TRANSMISSION>\n"
                        L"\n"
                    L"Shmoocon 2010\n"
                    L"Crypto Challenge #2\n"
                    L"\"A _bit_ of math!\"\n"
                    L"\n"
                    L"Difficulty: 4/9\n"
                    L"\n"
                    L"Example keys:\n" 
L"    Batou: 2E722FF98F8C65F2\n"
L"   Togusa: 6A99E55DE8EB4293\n"
L"  Aramaki: 158BF027068B4E3A\n"
L" Kusanagi: 78B9E2CBE36191C5\n"
                    L"\n"
                    L"<END TRANSMISSION>";

BOOL VerifySerial(UINT64 name, UINT64 serial)
{
    UINT64 result = 0;
    UINT64 a = (UINT64)1 << 63;
    UINT64 b = 0xA348FCCD93AEA5A7;

    if(name & a)
        name ^= b;
    if(serial & a)
        serial ^= b;

    while(serial)
    {
        if(serial & 1)
            result ^= name;

        serial >>= 1;
        name <<= 1;

        if(name & a)
            name ^= b;
    }

    return (result == 1);
}

   

