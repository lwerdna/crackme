#define DLG_LEN_X   196
#define DLG_LEN_Y   80

#define DLG_HR1_Y   15
#define DLG_HR2_Y   63
#define DLG_HR_LEN  DLG_LEN_X

#define ID_DIALOG  99 

#define ID_BUTTON1  100
#define ID_EDIT1    104
#define ID_EDIT2    105

#define ID_BUTTONMUSIC 106

#define ID_X        25

#define ID_TITLE    26

#define ID_XMFILE   32

#define ID_LTEXT1   64
#define ID_LTEXT2   65
#define ID_STATUS   66

#define ID_FRAME1 80

#define ID_ICON     90

