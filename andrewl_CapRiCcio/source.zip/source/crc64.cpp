#include <windows.h>

UINT64 poly = 0xC96C5795D7870F42;

// poly is: x^64 + x^62 + x^57 + x^55 + x^54 + x^53 + x^52 + x^47 + x^46 + x^45 + x^40 + x^39 + 
//          x^38 + x^37 + x^35 + x^33 + x^32 + x^31 + x^29 + x^27 + x^24 + x^23 + x^22 + x^21 + 
//          x^19 + x^17 + x^13 + x^12 + x^10 + x^9  + x^7  + x^4  + x^1  + 1
//
// represented here with lsb = highest degree term
//
// 1100100101101100010101111001010111010111100001110000111101000010_
// ||  |  | || ||   | | ||||  | | ||| | ||||    |||    |||| |    | |
// ||  |  | || ||   | | ||||  | | ||| | ||||    |||    |||| |    | +- x^64 (implied)
// ||  |  | || ||   | | ||||  | | ||| | ||||    |||    |||| |    |
// ||  |  | || ||   | | ||||  | | ||| | ||||    |||    |||| |    +--- x^62
// ||  |  | || ||   | | ||||  | | ||| | ||||    |||    |||| +-------- x^57
// .......................................................................
// ||
// |+---------------------------------------------------------------- x^1
// +----------------------------------------------------------------- x^0 (1)

UINT64 CRC64_table[256];

VOID CRC64_generate()
{
    for(INT i=0; i<256; ++i)
    {
        // input is dividend: as 0000000000000000000000000000000000000000000000000000000000000000<8-bit byte>
        // where the lsb of the 8-bit byte is the coefficient of the highest degree term (x^71) of the dividend
        // so division is really for input byte * x^64

        // you may wonder how 72 bits will fit in 64-bit data type... well as the shift-right occurs, 0's are supplied
        // on the left hand (most significant) side
    	UINT64 crc = i;

    	for(UINT j=0; j<8; ++j)
    	{
            // is current coefficient set?
    		if(crc & 1)
            {
                // yes, then assume it gets zero'd (by implied x^64 coefficient of dividend)
                crc >>= 1;
    
                // and add rest of the divisor
    			crc ^= poly;
            }
    		else
    		{
    			// no? then move to next coefficient
    			crc >>= 1;
            }
    	}
    
        CRC64_table[i] = crc;
    }
/*
    for(INT i=0; i<256; ++i)
    {
        printf("0x%016I64X, ", CRC64_table[i]);

        if(!((i+1)%4))
            printf("\n");
    }
*/
}

UINT64 CRC64_calculate(PBYTE stream, UINT n)
{
    UINT64 crc = 0;

    for(INT i=0; i<n; ++i)
    {
        BYTE index = stream[i] ^ crc;

        crc = (crc >> 8);

        crc ^= CRC64_table[index];
    }

    return crc;
}

