// 2009 andrewl

#include <windows.h>

#include "myresource.h"

extern "C"
{
#include "ufmod.h"
}


// 

// from crc64.cpp
extern UINT64 CRC64_table[256];
extern VOID CRC64_generate();
extern UINT64 CRC64_calculate(PBYTE stream, UINT n);



// process variables
HINSTANCE g_hInstance;

// music fx 
BOOL g_bMusicOn = 0;

// title scroll fx 
#define MSG_LEN 256

CHAR g_ScrollMsg[MSG_LEN] = {   ' ', ' ', ' ', ' ', ' ', ' ', 
                                'G', 'F', '(', '2', '^', '6', '4', ')', '[', 'X', ']', '/', '(', 'x', '^', '6',
                                '4', ' ', '+', ' ', 'x', '^', '6', '2', ' ', '+', ' ', 'x', '^', '5', '7', ' ', 
                                '+', ' ', 'x', '^', '5', '5', ' ', '+', ' ', 'x', '^', '5', '4', ' ', '+', ' ', 
                                'x', '^', '5', '3', ' ', '+', ' ', 'x', '^', '5', '2', ' ', '+', ' ', 'x', '^', 
                                '4', '7', ' ', '+', ' ', 'x', '^', '4', '6', ' ', '+', ' ', 'x', '^', '4', '5', 
                                ' ', '+', ' ', 'x', '^', '4', '0', ' ', '+', ' ', 'x', '^', '3', '9', ' ', '+', 
                                ' ', 'x', '^', '3', '8', ' ', '+', ' ', 'x', '^', '3', '7', ' ', '+', ' ', 'x', 
                                '^', '3', '5', ' ', '+', ' ', 'x', '^', '3', '3', ' ', '+', ' ', 'x', '^', '3', 
                                '2', ' ', '+', ' ', 'x', '^', '3', '1', ' ', '+', ' ', 'x', '^', '2', '9', ' ', 
                                '+', ' ', 'x', '^', '2', '7', ' ', '+', ' ', 'x', '^', '2', '4', ' ', '+', ' ', 
                                'x', '^', '2', '3', ' ', '+', ' ', 'x', '^', '2', '2', ' ', '+', ' ', 'x', '^', 
                                '2', '1', ' ', '+', ' ', 'x', '^', '1', '9', ' ', '+', ' ', 'x', '^', '1', '7', 
                                ' ', '+', ' ', 'x', '^', '1', '3', ' ', '+', ' ', 'x', '^', '1', '2', ' ', '+', 
                                ' ', 'x', '^', '1', '0', ' ', '+', ' ', 'x', '^', '9', ' ', '+', ' ', 'x', '^',
                                '7', ' ', '+', ' ', 'x', '^', '4', ' ', '+', ' ', 'x', '^', '1', ' ', '+', ' ',
                                '1', ')', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\0'
                        };

INT g_ScrollLen = 40;
INT g_ScrollStart = 0;
INT g_dir = 1;
#define SCROLL_TIMER 1

//
//
void * memcpy(void *d, const void * s, unsigned int n)
{
    __asm
    {
        mov     esi, dword ptr[s]
        mov     edi, dword ptr[d]
        mov     ecx, dword ptr[n]
        rep     movsb
    }

    return d;
}

// conversion
//
int hexStrToUint64(const char * hex_string, unsigned __int64 * arg_result)
{
    int bFuncRet = 0;

    unsigned __int64 result = 0;
    int len = 0, i = 0;
    unsigned char value;

    if(hex_string[0] == '0' && hex_string[1] == 'x')
        hex_string += 2;

    // find strlen
    len=-1;
    while(hex_string[++len]!='\0');

    if(len > 16)
        goto cleanup;

    for(i=0; i<len; i++)
    {
        char temp = hex_string[i];

        if((temp >= 0x30) && (temp <= 0x39)) // [0-9]
            value = temp - 0x30;
        else if(temp >= 0x41 && temp <= 0x46) // [A-F]
            value = temp - 0x37;
        else if(temp >= 0x61 && temp <= 0x66) // [A-Fa-f]
            value = temp - 0x57;
        else
            goto cleanup;

        result <<= 4;
        result |= value;
    }

    bFuncRet = 1;
    *arg_result = result;

    cleanup:

    return bFuncRet;
}

//
//
BOOL CALLBACK KeygenDialogProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
    PDRAWITEMSTRUCT pDIS;
    HBRUSH hBrushOld;
    RECT myRect;

    static HBRUSH hBgBrush = NULL;
    static HBRUSH hBgBrush2 = NULL;
    static HBRUSH hBgBrush3 = NULL;
    static HBRUSH hBgBrush4 = NULL;

    char buffer[64];

    switch(Message)
    {
        case WM_CTLCOLORDLG:
            return (BOOL) hBgBrush;

        // undocumented: control background color of static controls
        case WM_CTLCOLORSTATIC:
            SetTextColor((HDC)wParam, RGB(0, 0, 0));
            SetBkMode((HDC)wParam, TRANSPARENT);
            return (BOOL) hBgBrush;

        case WM_CTLCOLOREDIT:
            SetBkMode((HDC)wParam, TRANSPARENT);
            return (BOOL) hBgBrush2;

        //case WM_CREATE: // window created, no controls made

        case WM_INITDIALOG: // instead of WM_CREATE
        {
        
            RECT r;

            // get window size
            if(GetWindowRect(hWnd, &r))
            {
                r.right = r.right - r.left;
                r.bottom = r.bottom - r.top;

                // get screen size
                UINT xRes=GetDeviceCaps(GetDC(NULL), HORZRES);
                UINT yRes=GetDeviceCaps(GetDC(NULL), VERTRES);

                // resize/reposition window
                SetWindowPos(hWnd, 0, (xRes-r.right)/2, (yRes-r.bottom)/2, r.right, r.bottom, SWP_SHOWWINDOW);
            }

            // initialize colors 
            hBgBrush = CreateSolidBrush(RGB(0xC0, 0xC0, 0xC0)); // light grey
            hBgBrush2 = CreateSolidBrush(RGB(0xCF, 0xD9, 0xFF)); // light blue
            hBgBrush3 = CreateSolidBrush(RGB(0x70, 0x70, 0x70)); // darker grey
            hBgBrush4 = CreateSolidBrush(RGB(0x00, 0x00, 0x00)); // black

            // init music
            uFMOD_PlaySong((PVOID)ID_XMFILE, g_hInstance, XM_RESOURCE);
            g_bMusicOn = 1;

            // init status
            SetDlgItemText(hWnd, ID_STATUS, "August 2009 - andrewl/crackmes.de"); 

            // init scroller
            SetTimer(hWnd, SCROLL_TIMER, 100, NULL);

            // init window title 
            SetWindowText(hWnd, "Capriccio KeygenMe");

            // init icon
            SendMessage(hWnd, WM_SETICON, (WPARAM)1, (LPARAM)LoadIcon(g_hInstance, MAKEINTRESOURCE(ID_ICON)));

            // init name field, set focus
            SetFocus(GetDlgItem(hWnd, ID_EDIT1));

            // generate the CRC table
            CRC64_generate();

            break;
        }

        case WM_TIMER:
            {
                // find end of pointer
                int endp = g_ScrollStart + g_ScrollLen;
                if(endp >= MSG_LEN)
                    endp = MSG_LEN-1;
                    
                // temporary null terminate
                CHAR temp = g_ScrollMsg[endp];
                g_ScrollMsg[endp] = '\0';

                // print
                SetDlgItemText(hWnd, ID_TITLE, g_ScrollMsg + g_ScrollStart); 

                // and restore
                g_ScrollMsg[endp] = temp;

                // and increment
                if(g_dir)
                {
                    g_ScrollStart++;
                    if(g_ScrollStart >= (MSG_LEN-g_ScrollLen))
                        g_dir = 0;
                }
                else
                {
                    g_ScrollStart--;
                    if(g_ScrollStart <= 0)
                        g_dir = 1;
                }

            }

            break;

        case WM_CLOSE:
            // windows will send IDCANCEL after this, do shutdown shit there
            break;

        case WM_LBUTTONDOWN:
            SendMessage(hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            break;

        case WM_DRAWITEM:
            // one of the OWNER_DRAW items needs to be drawn
            // wParam == id of control to be drawn
            // lParam == LPDRAWITEMSTRUCT

            pDIS = (PDRAWITEMSTRUCT) lParam;

            switch(pDIS->CtlID)
            {
                case ID_FRAME1:
                    {
                        hBrushOld = (HBRUSH)SelectObject(pDIS->hDC, hBgBrush4);

                        // draw black background
                        myRect.left = myRect.top = 0;
                        myRect.right = DLG_LEN_X;
                        myRect.bottom = DLG_LEN_Y;
                        MapDialogRect(hWnd, &myRect);

                        // draw black border, grey inner
                        SelectObject(pDIS->hDC, hBgBrush);
                        Rectangle(pDIS->hDC, 0, 0, myRect.right, myRect.bottom);

                        // draw black horizontal rule 1
                        SelectObject(pDIS->hDC, hBgBrush4);

                        myRect.right = DLG_LEN_X;
                        myRect.bottom = DLG_HR1_Y;
                        MapDialogRect(hWnd, &myRect);
                        
                        MoveToEx(pDIS->hDC, 1, myRect.bottom, (LPPOINT)NULL);
                        LineTo(pDIS->hDC, myRect.right-1, myRect.bottom);

                        // draw black horizontal rule 2
                        myRect.right = DLG_LEN_X;
                        myRect.bottom = DLG_HR2_Y;
                        MapDialogRect(hWnd, &myRect);

                        MoveToEx(pDIS->hDC, 1, myRect.bottom+1, (LPPOINT)NULL);
                        LineTo(pDIS->hDC, myRect.right-1, myRect.bottom+1);

                        break;
                    }

                default:
                    if(pDIS->itemState & ODS_SELECTED)
                        hBrushOld = (HBRUSH)SelectObject(pDIS->hDC, hBgBrush3);
                    else
                        hBrushOld = (HBRUSH)SelectObject(pDIS->hDC, hBgBrush2);

                    // assume it's buttons from BS_OWNERDRAW
                    FillRect(pDIS->hDC, &pDIS->rcItem, NULL); // 3rd param ignored
                    Rectangle(pDIS->hDC, pDIS->rcItem.left, pDIS->rcItem.top, pDIS->rcItem.right, pDIS->rcItem.bottom);
                    GetDlgItemText(hWnd, pDIS->CtlID, buffer, 63);
                    SetBkMode(pDIS->hDC, TRANSPARENT);

                    if(!(pDIS->CtlID == ID_BUTTONMUSIC) || g_bMusicOn)
                        DrawText(pDIS->hDC, buffer, -1, &pDIS->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            }

            SelectObject(pDIS->hDC, hBrushOld);

            break;

        case WM_COMMAND:
            switch(LOWORD(wParam))
            {
                // reach here if user clicked "X" button
                case ID_X:
                // reach here if alt+f4 and windows sends IDCANCEL
                case IDCANCEL:
                    if(hBgBrush)
                        DeleteObject(hBgBrush);
                    if(hBgBrush2)
                        DeleteObject(hBgBrush2);
                    if(hBgBrush3)
                        DeleteObject(hBgBrush3);
                    if(hBgBrush4)
                        DeleteObject(hBgBrush4);

                    uFMOD_PlaySong(0, 0, 0);

                    EndDialog(hWnd, IDOK);
                    break;

                case ID_BUTTON1:
                {
                    SetDlgItemText(hWnd, ID_STATUS, "Never give up.");
                    
                    CHAR name[17];
                    CHAR serial[17]; // serial form: XXXXXXXXXXXXXXXX
                    BYTE region[MSG_LEN];

                    // get name
                    UINT nName = GetDlgItemText(hWnd, ID_EDIT1, name, 17);
                    if(nName < 4)
                        break;

                    // get serial
                    UINT nSerial = GetDlgItemText(hWnd, ID_EDIT2, serial, 17);
                    if(nSerial != 16)
                        break;

                    // decode serial
                    UINT64 qSerial;
                    if(!hexStrToUint64(serial, &qSerial))
                        break;

                    // make copy of scroll message
                    memcpy(region, g_ScrollMsg, MSG_LEN);

                    // add in the name
                    for(UINT i=0; i<nName; ++i)
                        region[i<<4] = name[i];
                    
                    // add in the serial
                    *(PUINT64)(region + (nName<<2)) = qSerial;

                    // crc of region
                    if(CRC64_calculate(region, MSG_LEN) == 0x6963636972706163)
                        SetDlgItemText(hWnd, ID_STATUS, "Congratulations! Send Keygen!");

                    break;
                }

                case ID_BUTTONMUSIC:
                {
                    if(g_bMusicOn)
                    {
                        uFMOD_Pause();
                        g_bMusicOn = 0;
                    }
                    else
                    {
                        uFMOD_Resume();
                        g_bMusicOn = 1;
                    }

                    RedrawWindow(GetDlgItem(hWnd, ID_BUTTONMUSIC), 0, 0, RDW_INVALIDATE);

                    break;
                }

            break;
        }

        default:
        {
            // DefWindowProc() automatically called!
            // 
            // based on whether we return TRUE (we handled it) or FALSE (DefWindowProc() should)
            break;
        }
    }

    return FALSE;
}

VOID MyEntry()
{
    g_hInstance = GetModuleHandle(0);

    DialogBox(g_hInstance, MAKEINTRESOURCE(ID_DIALOG), NULL, KeygenDialogProc);

    ExitProcess(0);
}
