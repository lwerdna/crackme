"UPSKiRT" CrackME

- serial verification uses elementary number theory
- uses just four or five different calls to custom big number lib
- values of big numbers in memory are EXTREMELY obvious

The serial verification is based on a single call, no decoys. The only anti-debug is distracting multimedia :) I apologise in advance if any bugs are found. Kindly report them immediately. Crackme and a working keygen were tested on 32-bit XP SP2.

Keygen only! Enjoy!