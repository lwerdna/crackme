// os includes
#include <windows.h>

// this includes
#include "apl.h"
#include "myresource.h"

// my libs
#include "funconsolepicframe.h"
#include "funcrt.h"
#include "funcrtfuncs.h"

extern "C" {
#include "funbignum.h"
}

// others' lib includes
#include "ufmod.h"
#include "aplib_depack.h"

FunConsolePicFrame  *g_pFCPF;
unsigned char       *g_pfa=0;

unsigned int        g_effectid=0;
HANDLE              g_heffectchangeevent=0;
HANDLE              g_heffectquitevent=0;

CHAR_INFO text_overlay[80*59]={0};
unsigned char text_overlay_map[80*59]={0};

void printToCharInfoPointer(char * ptext, int len, UINT x, UINT y, CHAR_INFO * pci, WORD attrs=0x000F, unsigned char mapflags=1)
{
    int i=x+y*80;
    unsigned int startline=i;

    while(len-- > 0)
    {
        if(*ptext==0x0A)
        {
            i=startline+80;
            startline=i;
            ptext++;
            continue;
        }
   
        pci[i].Char.AsciiChar=*ptext;
        pci[i].Attributes=attrs;
        text_overlay_map[i]=mapflags;
        i++;
        ptext++;
    }
}

void printToCharInfoPointerLine(char * ptext, int len, UINT x, UINT y, CHAR_INFO * pci, WORD attrs=0x000F, unsigned char mapflags=1)
{
    char linebuff[81];
    memset(linebuff, 0x20, 81);
    linebuff[80]=0;
  
    int i=0;
    while(*ptext)
        linebuff[i++]=*ptext++;

    printToCharInfoPointer(linebuff, 80, x, y, pci, attrs, mapflags);
}

void displayInput(char * ptext, int len)
{
    //   screen: 00  01  02 ...         77  78  79
    //     buff:        [00][01]...[74][75]
    // contents:     ||                 ||
    //
    // so we have [1..74] = 74   so 24char-24char-24char
    #define LEN 76
    CHAR line[LEN];

    if(*ptext)
    {
        memset(line, 205, LEN);
        line[0]=201;
        line[LEN-1]=187;
        printToCharInfoPointer(line, LEN, 2, 27, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 1);
        line[0]=200;
        line[LEN-1]=188;
        printToCharInfoPointer(line, LEN, 2, 29, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 1);
        memset(line, ' ', LEN-1);
        line[0]=186;
        line[LEN-1]=186;
        memcpy(line+1, ptext, len);
        printToCharInfoPointer(line, LEN, 2, 28, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 1);
    }
    else
    {
        memset(line, 0, LEN);
        printToCharInfoPointer(line, LEN, 2, 27, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 0);
        printToCharInfoPointer(line, LEN, 2, 28, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 0);
        printToCharInfoPointer(line, LEN, 2, 29, text_overlay, FOREGROUND_RED | FOREGROUND_INTENSITY, 0);
    }
}

BOOL verifySerial(PCHAR serialin)
{
    CHAR serial[75];
    strcpy(serial, serialin);

    if(serial[24] != '-' || serial[49] != '-')
        return 0;

    serial[24]=serial[49]=serial[74]=0;

    // ensure crackmes.de is in first block
    char *required="#cRaCkInG4NeWbIeS";
    for(int i=0; i<11; ++i)
    {
        int j;
        for(j=0; j<24; ++j)
            if(serial[j]==required[i])
                break;

        if(j==24)
            return 0;
    }

    // combine characters
    for(int i=0; i<12; ++i)
        serial[i] ^= (serial[i+12] << 4);

    FUNBIGNUM na, nb, nc, p1, p2;
    FBN_init(&na);
    FBN_init(&nb);
    FBN_init(&nc);
    FBN_init(&p1);
    FBN_init(&p2);

    FBN_from_hex_string(&p1, "19FBD41D69AA3D86009A968D");
    FBN_from_hex_string(&p2, "1B6F141F98EEB619BC036051");

    FBN_from_bytes_bend(&na, (PUCHAR)serial, 12);
    FBN_from_hex_string(&nb, serial+25);
    FBN_from_hex_string(&nc, serial+50);

    FBN_mul(&p1, &p1, &nb);
    FBN_mul(&p2, &p2, &nc);
    FBN_sub(&p1, &p1, &p2);

    if(FBN_cmp(&p1, &na))
        return 0;
    else
        return 1;
}

DWORD WINAPI EffectThread(LPVOID param)
{
    unsigned char   *pics[113];
    pics[0]=g_pfa+PFA_CLUBWALK001_BMP_BIN_INDEX+4;
    pics[1]=g_pfa+PFA_CLUBWALK002_BMP_BIN_INDEX+4;
    pics[2]=g_pfa+PFA_CLUBWALK003_BMP_BIN_INDEX+4;
    pics[3]=g_pfa+PFA_CLUBWALK004_BMP_BIN_INDEX+4;
    pics[4]=g_pfa+PFA_CLUBWALK005_BMP_BIN_INDEX+4;
    pics[5]=g_pfa+PFA_CLUBWALK006_BMP_BIN_INDEX+4;
    pics[6]=g_pfa+PFA_CLUBWALK007_BMP_BIN_INDEX+4;
    pics[7]=g_pfa+PFA_CLUBWALK008_BMP_BIN_INDEX+4;
    pics[8]=g_pfa+PFA_CLUBWALK009_BMP_BIN_INDEX+4;
    pics[9]=g_pfa+PFA_CLUBWALK010_BMP_BIN_INDEX+4;
    pics[10]=g_pfa+PFA_CLUBWALK011_BMP_BIN_INDEX+4;
    pics[11]=g_pfa+PFA_CLUBWALK012_BMP_BIN_INDEX+4;
    pics[12]=g_pfa+PFA_CLUBWALK013_BMP_BIN_INDEX+4;
    pics[13]=g_pfa+PFA_CLUBWALK014_BMP_BIN_INDEX+4;
    pics[14]=g_pfa+PFA_CLUBWALK015_BMP_BIN_INDEX+4;
    pics[15]=g_pfa+PFA_CLUBWALK016_BMP_BIN_INDEX+4;
    pics[16]=g_pfa+PFA_CLUBWALK017_BMP_BIN_INDEX+4;
    pics[17]=g_pfa+PFA_CLUBWALK018_BMP_BIN_INDEX+4;
    pics[18]=g_pfa+PFA_CLUBWALK019_BMP_BIN_INDEX+4;
    pics[19]=g_pfa+PFA_CLUBWALK020_BMP_BIN_INDEX+4;
    pics[20]=g_pfa+PFA_CLUBWALK021_BMP_BIN_INDEX+4;
    pics[21]=g_pfa+PFA_CLUBWALK022_BMP_BIN_INDEX+4;
    pics[22]=g_pfa+PFA_CLUBWALK023_BMP_BIN_INDEX+4;
    pics[23]=g_pfa+PFA_CLUBWALK024_BMP_BIN_INDEX+4;
    pics[24]=g_pfa+PFA_CLUBWALK025_BMP_BIN_INDEX+4;
    pics[25]=g_pfa+PFA_CLUBWALK026_BMP_BIN_INDEX+4;
    pics[26]=g_pfa+PFA_CLUBWALK027_BMP_BIN_INDEX+4;
    pics[27]=g_pfa+PFA_CLUBWALK028_BMP_BIN_INDEX+4;
    pics[28]=g_pfa+PFA_CLUBWALK029_BMP_BIN_INDEX+4;
    pics[29]=g_pfa+PFA_CLUBWALK030_BMP_BIN_INDEX+4;
    pics[30]=g_pfa+PFA_CLUBWALK031_BMP_BIN_INDEX+4;
    pics[31]=g_pfa+PFA_CLUBWALK032_BMP_BIN_INDEX+4;
    pics[32]=g_pfa+PFA_CLUBWALK033_BMP_BIN_INDEX+4;
    pics[33]=g_pfa+PFA_CLUBWALK034_BMP_BIN_INDEX+4;
    pics[34]=g_pfa+PFA_CLUBWALK035_BMP_BIN_INDEX+4;
    pics[35]=g_pfa+PFA_CLUBWALK036_BMP_BIN_INDEX+4;
    pics[36]=g_pfa+PFA_CLUBWALK037_BMP_BIN_INDEX+4;
    pics[37]=g_pfa+PFA_CLUBWALK038_BMP_BIN_INDEX+4;
    pics[38]=g_pfa+PFA_CLUBWALK039_BMP_BIN_INDEX+4;
    pics[39]=g_pfa+PFA_CLUBWALK040_BMP_BIN_INDEX+4;
    pics[40]=g_pfa+PFA_CLUBWALK041_BMP_BIN_INDEX+4;
    pics[41]=g_pfa+PFA_CLUBWALK042_BMP_BIN_INDEX+4;
    pics[42]=g_pfa+PFA_CLUBWALK043_BMP_BIN_INDEX+4;
    pics[43]=g_pfa+PFA_CLUBWALK044_BMP_BIN_INDEX+4;
    pics[44]=g_pfa+PFA_CLUBWALK045_BMP_BIN_INDEX+4;
    pics[45]=g_pfa+PFA_CLUBWALK046_BMP_BIN_INDEX+4;
    pics[46]=g_pfa+PFA_CLUBWALK047_BMP_BIN_INDEX+4;
    pics[47]=g_pfa+PFA_CLUBWALK048_BMP_BIN_INDEX+4;
    pics[48]=g_pfa+PFA_CLUBWALK049_BMP_BIN_INDEX+4;
    pics[49]=g_pfa+PFA_CLUBWALK050_BMP_BIN_INDEX+4;
    pics[50]=g_pfa+PFA_CLUBWALK051_BMP_BIN_INDEX+4;
    pics[51]=g_pfa+PFA_CLUBWALK052_BMP_BIN_INDEX+4;
    pics[52]=g_pfa+PFA_CLUBWALK053_BMP_BIN_INDEX+4;
    pics[53]=g_pfa+PFA_CLUBWALK054_BMP_BIN_INDEX+4;
    pics[54]=g_pfa+PFA_CLUBWALK055_BMP_BIN_INDEX+4;
    pics[55]=g_pfa+PFA_CLUBWALK056_BMP_BIN_INDEX+4;
    pics[56]=g_pfa+PFA_CLUBWALK057_BMP_BIN_INDEX+4;
    pics[57]=g_pfa+PFA_CLUBWALK058_BMP_BIN_INDEX+4;
    pics[58]=g_pfa+PFA_CLUBWALK059_BMP_BIN_INDEX+4;
    pics[59]=g_pfa+PFA_CLUBWALK060_BMP_BIN_INDEX+4;
    pics[60]=g_pfa+PFA_CLUBWALK061_BMP_BIN_INDEX+4;
    pics[61]=g_pfa+PFA_CLUBWALK062_BMP_BIN_INDEX+4;
    pics[62]=g_pfa+PFA_CLUBWALK063_BMP_BIN_INDEX+4;
    pics[63]=g_pfa+PFA_CLUBWALK064_BMP_BIN_INDEX+4;
    pics[64]=g_pfa+PFA_CLUBWALK065_BMP_BIN_INDEX+4;
    pics[65]=g_pfa+PFA_CLUBWALK066_BMP_BIN_INDEX+4;
    pics[66]=g_pfa+PFA_CLUBWALK067_BMP_BIN_INDEX+4;
    pics[67]=g_pfa+PFA_CLUBWALK068_BMP_BIN_INDEX+4;
    pics[68]=g_pfa+PFA_CLUBWALK069_BMP_BIN_INDEX+4;
    pics[69]=g_pfa+PFA_CLUBWALK070_BMP_BIN_INDEX+4;
    pics[70]=g_pfa+PFA_CLUBWALK071_BMP_BIN_INDEX+4;
    pics[71]=g_pfa+PFA_CLUBWALK072_BMP_BIN_INDEX+4;
    pics[72]=g_pfa+PFA_CLUBWALK073_BMP_BIN_INDEX+4;
    pics[73]=g_pfa+PFA_CLUBWALK074_BMP_BIN_INDEX+4;
    pics[74]=g_pfa+PFA_CLUBWALK075_BMP_BIN_INDEX+4;
    pics[75]=g_pfa+PFA_CLUBWALK076_BMP_BIN_INDEX+4;
    pics[76]=g_pfa+PFA_CLUBWALK077_BMP_BIN_INDEX+4;
    pics[77]=g_pfa+PFA_CLUBWALK078_BMP_BIN_INDEX+4;
    pics[78]=g_pfa+PFA_CLUBWALK079_BMP_BIN_INDEX+4;
    pics[79]=g_pfa+PFA_CLUBWALK080_BMP_BIN_INDEX+4;
    pics[80]=g_pfa+PFA_CLUBWALK081_BMP_BIN_INDEX+4;
    pics[81]=g_pfa+PFA_CLUBWALK082_BMP_BIN_INDEX+4;
    pics[82]=g_pfa+PFA_CLUBWALK083_BMP_BIN_INDEX+4;
    pics[83]=g_pfa+PFA_CLUBWALK084_BMP_BIN_INDEX+4;
    pics[84]=g_pfa+PFA_CLUBWALK085_BMP_BIN_INDEX+4;
    pics[85]=g_pfa+PFA_CLUBWALK086_BMP_BIN_INDEX+4;
    pics[86]=g_pfa+PFA_CLUBWALK087_BMP_BIN_INDEX+4;
    pics[87]=g_pfa+PFA_CLUBWALK088_BMP_BIN_INDEX+4;
    pics[88]=g_pfa+PFA_CLUBWALK089_BMP_BIN_INDEX+4;
    pics[89]=g_pfa+PFA_CLUBWALK090_BMP_BIN_INDEX+4;
    pics[90]=g_pfa+PFA_CLUBWALK091_BMP_BIN_INDEX+4;
    pics[91]=g_pfa+PFA_CLUBWALK092_BMP_BIN_INDEX+4;
    pics[92]=g_pfa+PFA_CLUBWALK093_BMP_BIN_INDEX+4;
    pics[93]=g_pfa+PFA_CLUBWALK094_BMP_BIN_INDEX+4;
    pics[94]=g_pfa+PFA_CLUBWALK095_BMP_BIN_INDEX+4;
    pics[95]=g_pfa+PFA_CLUBWALK096_BMP_BIN_INDEX+4;
    pics[96]=g_pfa+PFA_CLUBWALK097_BMP_BIN_INDEX+4;
    pics[97]=g_pfa+PFA_CLUBWALK098_BMP_BIN_INDEX+4;
    pics[98]=g_pfa+PFA_CLUBWALK099_BMP_BIN_INDEX+4;
    pics[99]=g_pfa+PFA_CLUBWALK100_BMP_BIN_INDEX+4;
    pics[100]=g_pfa+PFA_CLUBWALK101_BMP_BIN_INDEX+4;
    pics[101]=g_pfa+PFA_CLUBWALK102_BMP_BIN_INDEX+4;
    pics[102]=g_pfa+PFA_CLUBWALK103_BMP_BIN_INDEX+4;
    pics[103]=g_pfa+PFA_CLUBWALK104_BMP_BIN_INDEX+4;
    pics[104]=g_pfa+PFA_CLUBWALK105_BMP_BIN_INDEX+4;
    pics[105]=g_pfa+PFA_CLUBWALK106_BMP_BIN_INDEX+4;
    pics[106]=g_pfa+PFA_CLUBWALK107_BMP_BIN_INDEX+4;
    pics[107]=g_pfa+PFA_CLUBWALK108_BMP_BIN_INDEX+4;
    pics[108]=g_pfa+PFA_CLUBWALK109_BMP_BIN_INDEX+4;
    pics[109]=g_pfa+PFA_CLUBWALK110_BMP_BIN_INDEX+4;
    pics[110]=g_pfa+PFA_CLUBWALK111_BMP_BIN_INDEX+4;
    pics[111]=g_pfa+PFA_CLUBWALK112_BMP_BIN_INDEX+4;
    pics[112]=g_pfa+PFA_CLUBWALK113_BMP_BIN_INDEX+4;

    WaitForSingleObject(g_heffectchangeevent, INFINITE);

    while(1)
    {
        top:

        ResetEvent(g_heffectchangeevent);

        if(WaitForSingleObject(g_heffectquitevent, 0)==WAIT_OBJECT_0)
            break;

        // flash random pics from it
        if(g_effectid==1)
        {
            while(1)
            {
                if(WaitForSingleObject(g_heffectchangeevent, 0)==WAIT_OBJECT_0) goto top;
                
                g_pFCPF->WritePictureCharInfo((CHAR_INFO *)pics[GetTickCount()%113], 80, 59, 0, 0);
                Sleep(300);
            }
        }

        // play full
        if(g_effectid==0)
        {
            for(int i=0; i<113; ++i)
            {
                CHAR_INFO * pci=(CHAR_INFO *)pics[i];
                pci+=4;
               
                g_pFCPF->WritePictureCharInfo((CHAR_INFO *)pics[i], 80, 59, 0, 0);
                if(WaitForSingleObject(g_heffectchangeevent, 100)==WAIT_OBJECT_0) goto top;
            }
        }

        // butt around anim
        if(g_effectid==2)
        {
            int i=24;
            int d=1;
            while(1)
            {
                g_pFCPF->WritePictureCharInfo((CHAR_INFO *)pics[i], 80, 59, 0, 0);
                 
                if(WaitForSingleObject(g_heffectchangeevent, 50)==WAIT_OBJECT_0) goto top;

                i+=d;
                if(i==24 || i==34)
                    d*=-1;
            }
        }
        // lift skirt
        if(g_effectid==3)
        {
            int i=47;
            int d=1;
            while(1)
            {
                g_pFCPF->WritePictureCharInfo((CHAR_INFO *)pics[i], 80, 59, 0, 0);
                 
                if(WaitForSingleObject(g_heffectchangeevent, 50)==WAIT_OBJECT_0) goto top;

                i+=d;
                if(i==47 || i==61)
                    d*=-1;
            }
        }
    }

    return 0;
}

int MyEntry()
{
    HWAVEOUT            *phWaveOut=0;

    HANDLE              hEffectThread=0;

    HANDLE              hStdIn=0;

    DWORD               dwRet;

    CHAR                userInput[78]={0};
    UINT                userInputLen=0;

    // my CRT
    crt_initialize();

    if(!(g_pfa=(PUCHAR)malloc(PFA_TOTALSIZE)))
        goto cleanup;
   
    if(!(g_pFCPF=new FunConsolePicFrame("UPSKiRT", 80, 59)))
        goto cleanup;

    // text overlay
    PCHAR info =  " UPSKiRT CRACKME by andrewl [XM: rung by smirk] [PLAYER: ufmod]";
    PCHAR info2 = " Hello to #c4n and crackmes.de!                               http://andrewl.us";
    printToCharInfoPointerLine(info, strlen(info), 0, 2, text_overlay, 0x007C, 1); 
    printToCharInfoPointerLine(info2, strlen(info2), 0, 56, text_overlay, 0x007C, 1);
    g_pFCPF->SetTextOverlay(text_overlay, text_overlay_map);

    // get console input handle, set no echo
    hStdIn = GetStdHandle(STD_INPUT_HANDLE);
    SetConsoleMode(hStdIn, 0);

    aP_depack_asm(pfa_array, g_pfa);

    g_heffectchangeevent=CreateEvent(0, 1, 0, 0); // no security, manual reset, initially 0, no name
    g_heffectquitevent=CreateEvent(0, 1, 0, 0);
    g_effectid=0;

    if(!(hEffectThread=CreateThread(0, 0, EffectThread, 0, 0, 0)))
        goto cleanup;

    phWaveOut = uFMOD_PlaySong(g_pfa+PFA_RUNG_XM_INDEX, (void *)PFA_RUNG_XM_SIZE, XM_MEMORY);

    while(1)
    {
        long row_order;

        //printf("order:row=%d:%d\n", (row_order&0xFFFF0000)>>16, row_order&0x0000FFFF);

        UINT effectsequence[]={0,1,2,3}; 

        for(int k=0; ; k++)
        {
            short rowin=(uFMOD_GetRowOrder() & 0xFFFF0000)>>16;

            g_effectid=effectsequence[k%4];
            SetEvent(g_heffectchangeevent);

            while(((row_order=uFMOD_GetRowOrder()) & 0xFFFF0000)>>16 == rowin)
            {
                INPUT_RECORD er;
                PeekConsoleInput(hStdIn, &er, 1, &dwRet);

                if(dwRet != 0)
                {
                    ReadConsoleInput(hStdIn, &er, 1, &dwRet);

                    if(er.EventType==KEY_EVENT)
                    {
                        KEY_EVENT_RECORD ker = er.Event.KeyEvent;
                                                
                        if(ker.bKeyDown==1)
                        {
                            if(VK_BACK == ker.wVirtualKeyCode)
                            {
                                if(userInputLen > 0)
                                    userInput[--userInputLen] = 0;
                            }
                            else if(VK_ESCAPE == ker.wVirtualKeyCode)
                            {
                                memset(userInput, 0, 74);
                                userInputLen=0;
                            }
                            else
                            {
                                if(ker.uChar.AsciiChar)
                                    if(userInputLen < 74)
                                        userInput[userInputLen++] = ker.uChar.AsciiChar;

                            }

                            userInput[userInputLen] = 0;
                            displayInput(userInput, userInputLen);

                            if(userInputLen == 74)
                                if(verifySerial(userInput))
                                    goto goodboy;
                        }
                    }
                }

                Sleep(60);
            }
        }
    }

    goodboy:

    // signal, wait for thread
    SetEvent(g_heffectquitevent);
    SetEvent(g_heffectchangeevent);
    WaitForSingleObject(hEffectThread, INFINITE);

    // kill song
    uFMOD_StopSong();

    // display message
    CHAR_INFO * fakepic = (CHAR_INFO *) (g_pfa+PFA_CLUBWALK001_BMP_BIN_INDEX+4);
    memset(fakepic, 0, 80*59*sizeof(CHAR_INFO));
    memset(text_overlay_map, 0, 80*59);
    char * nicework = "Nice freakin' work! Email keygen to andrewwl@ufl.edu.";
    printToCharInfoPointer(nicework, strlen(nicework), 13, 28, fakepic, FOREGROUND_RED | FOREGROUND_INTENSITY, 0);
    g_pFCPF->WritePictureCharInfo(fakepic, 80, 59, 0, 0); 

    // pause until keypress
    ReadConsole(hStdIn, userInput, 1, &dwRet, 0);

    cleanup:

    if(g_pfa)
        free(g_pfa);

    crt_uninitialize();

    if(hEffectThread)
        CloseHandle(hEffectThread);
    if(g_heffectchangeevent)
        CloseHandle(g_heffectchangeevent);
    if(g_heffectquitevent)
        CloseHandle(g_heffectquitevent);

    ExitProcess(0);
}
