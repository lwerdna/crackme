import sys
import string

#------------------------------------------------------------------------------
# challenge 1
#------------------------------------------------------------------------------
def gen1(name):
    d = 65537
    n = 1821668788150059822966422307930288186476927434330004078983325993614616857
    # eulerphi(n) = 1821668770858768688568830104173455278614348858086775854542934108212297728
    # e = d^-1 (mod eulerphi(n))
    e = 174725878413998504300527427786354881690797517767573630493566745566969857
    # convert name to number eg: "AAAA" -> 0x41414141
    m = 0;
    for char in name:
        m = m*256 + ord(char);
    if m > n:
        m = m % n;
    # encrypt name
    c = pow(m, e, n);
    # write ciphertext as hex string
    return "%d" % c;

#------------------------------------------------------------------------------
# challenge 2
#------------------------------------------------------------------------------
def invert(value,prime): # from MR.HAANDI ECDLP v0.3a solver
    if value==0: raise ZeroDivisionError
    a,b=value,prime
    x,inverse = 0,1
    while b != 0:
        a,b,q =b,a % b, a // b
        x,inverse = inverse-q*x,x
    return inverse

def crt(relations):
    result=0
    n=1
    for relation in relations:
        n*=relation[0]
    for relation in relations:
        result+=relation[1]*(n//relation[0])*invert((n//relation[0]),relation[0])
    return result % n

def gen2(name):
    if len(name) > 10:
        name = name[0:10]
    else:
        while len(name) < 10:
            name = name + 'S'
    rotor0 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~......."
    rotor1 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~..........."
    rotor2 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~............."
    rotor3 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~................."
    rotor4 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~..................."
    rotor5 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~......................."
    rotor6 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~....................................."
    rotor7 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~........................................."
    rotor8 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~..............................................."
    rotor9 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ`abcdefghijklmnopqrstuvwxyz{|}~................................................."
    # rotors have sizes 97,101,103,107,109,113,127,131,137,139
    ind0 = string.index(rotor0, name[0])
    ind1 = string.index(rotor1, name[1])
    ind2 = string.index(rotor2, name[2])
    ind3 = string.index(rotor3, name[3])
    ind4 = string.index(rotor4, name[4])
    ind5 = string.index(rotor5, name[5])
    ind6 = string.index(rotor6, name[6])
    ind7 = string.index(rotor7, name[7])
    ind8 = string.index(rotor8, name[8])
    ind9 = string.index(rotor9, name[9])
    # now the system is equivalent to:
    # x = ind0 (mod 97) 
    # x = ind1 (mod 101)
    # x = ind2 (mod 103)
    # x = ind3 (mod 107)
    # etc... this is Chinese Remainder Theorem
    relations = ((97,ind0),(101,ind1),(103,ind2),(107,ind3),(109,ind4),(113,ind5),(127,ind6),(131,ind7),(137,ind8),(139,ind9))
    serial = crt(relations)
    return "%d" % serial

#------------------------------------------------------------------------------
# challenge 3
#------------------------------------------------------------------------------
def gen3(name):
    # convert name to number eg: "AAAA" -> 0x41414141
    state = 0;
    for char in name:
        state = state*256 + ord(char)
    state &= (2**64-1)
    for i in range(65537):
        temp = state & 0x1B
        sum = 1
        while temp:
            sum ^= (temp & 1);
            temp >>= 1;
    
        state = (state >> 1) | (sum<<63);
    return "%d" % state;

#------------------------------------------------------------------------------
# challenge 4
#------------------------------------------------------------------------------

# order of both is 18446693477654742300
#g1 = [120, 9, 5, 217, 233, 133, 237, 134, 222, 64, 176, 248, 28, 195, 173, 286, 18, 111, 136, 13, 282, 146, 211, 235, 50, 302, 294, 78, 130, 288, 88, 330, 141, 79, 139, 100, 45, 274, 262, 206, 167, 207, 224, 31, 305, 182, 284, 164, 225, 51, 290, 269, 277, 175, 232, 66, 255, 185, 103, 296, 82, 7, 319, 267, 258, 311, 68, 70, 63, 99, 108, 295, 307, 154, 349, 297, 62, 259, 193, 326, 32, 122, 303, 285, 186, 199, 353, 14, 144, 147, 159, 20, 321, 312, 165, 272, 40, 86, 4, 220, 213, 93, 219, 309, 23, 212, 180, 318, 338,241, 234, 53, 335, 6, 112, 110, 228, 155, 121, 42, 345, 132, 245, 24, 350, 8, 324, 226, 356, 310, 252, 106, 344, 135, 137, 119, 169, 170, 123, 204, 101, 89, 250, 128, 69, 337, 81, 1, 107, 181, 357, 346, 179, 289, 242, 304, 253, 74, 33, 113, 332, 15, 348, 300,328, 215, 87, 216, 247, 254, 246, 178, 203, 54, 231, 127, 57, 10, 37, 39, 27, 98, 76, 47, 41, 283, 333, 276, 109, 30, 329, 52, 44, 298, 151, 90, 331, 190, 191, 273, 266, 59, 183, 149, 65, 140, 341, 29, 275, 92, 61, 49, 355, 156, 314, 67, 223, 58, 209, 280, 188, 208, 118, 229, 83, 72, 71, 19, 35, 84, 104, 299, 316, 336, 243, 163, 16, 301, 227, 351, 158, 239, 236, 171, 306, 126, 138, 153,343, 22, 48, 205, 160, 256, 238, 257, 261, 291, 77, 75, 263, 91, 334, 264, 218, 46, 94, 38, 174, 194, 96, 152, 340, 43, 270, 198,161, 315, 36, 80, 150, 339, 260, 230, 265, 210, 189, 202, 25, 214, 2, 34, 143, 142, 145, 102, 162, 271, 347, 221, 201, 292, 327, 131, 172, 268, 354, 184, 196, 105, 342, 313, 95, 278, 3, 317, 168, 320, 279, 17, 129, 325, 322, 12, 60, 281, 116, 200, 308, 323, 55, 56, 251, 157, 249, 115, 26, 287, 85, 11, 192, 166, 114, 117, 124, 197, 73, 125, 21, 240, 244, 187, 177, 352, 97, 148, 293];
#g2 = PG_pow(g1, 18443422434254745293)
sbox0 = [ 
      0,
    120,   9,   5, 217, 233, 133, 237, 134, 222,  64, 176, 248,  28, 195, 173, 286,
     18, 111, 136,  13, 282, 146, 211, 235,  50, 302, 294,  78, 130, 288,  88, 330,
    141,  79, 139, 100,  45, 274, 262, 206, 167, 207, 224,  31, 305, 182, 284, 164,
    225,  51, 290, 269, 277, 175, 232,  66, 255, 185, 103, 296,  82,   7, 319, 267,
    258, 311,  68,  70,  63,  99, 108, 295, 307, 154, 349, 297,  62, 259, 193, 326,
     32, 122, 303, 285, 186, 199, 353,  14, 144, 147, 159,  20, 321, 312, 165, 272,
     40,  86,   4, 220, 213,  93, 219, 309,  23, 212, 180, 318, 338, 241, 234,  53,
    335,   6, 112, 110, 228, 155, 121,  42, 345, 132, 245,  24, 350,   8, 324, 226,
    356, 310, 252, 106, 344, 135, 137, 119, 169, 170, 123, 204, 101,  89, 250, 128,
     69, 337,  81,   1, 107, 181, 357, 346, 179, 289, 242, 304, 253,  74,  33, 113,
    332,  15, 348, 300, 328, 215,  87, 216, 247, 254, 246, 178, 203,  54, 231, 127,
     57,  10,  37,  39,  27,  98,  76,  47,  41, 283, 333, 276, 109,  30, 329,  52,
     44, 298, 151,  90, 331, 190, 191, 273, 266,  59, 183, 149,  65, 140, 341,  29,
    275,  92,  61,  49, 355, 156, 314,  67, 223,  58, 209, 280, 188, 208, 118, 229,
     83,  72,  71,  19,  35,  84, 104, 299, 316, 336, 243, 163,  16, 301, 227, 351,
    158, 239, 236, 171, 306, 126, 138, 153, 343,  22,  48, 205, 160, 256, 238, 257,
    261, 291,  77,  75, 263,  91, 334, 264, 218,  46,  94,  38, 174, 194,  96, 152,
    340,  43, 270, 198, 161, 315,  36,  80, 150, 339, 260, 230, 265, 210, 189, 202,
     25, 214,   2,  34, 143, 142, 145, 102, 162, 271, 347, 221, 201, 292, 327, 131,
    172, 268, 354, 184, 196, 105, 342, 313,  95, 278,   3, 317, 168, 320, 279,  17,
    129, 325, 322,  12,  60, 281, 116, 200, 308, 323,  55,  56, 251, 157, 249, 115,
     26, 287,  85,  11, 192, 166, 114, 117, 124, 197,  73, 125,  21, 240, 244, 187,
    177, 352,  97, 148, 293
];

src = [
      0,
     90, 158,  18,  66, 111, 236,  16, 157,  74, 153, 313, 200,  78, 151, 203, 210,
    317, 168, 240,  28, 349, 337, 214,   8,  82, 292, 279, 259,  25, 232,  14,  42,
    355, 193, 245, 144, 176, 224,  33, 149, 255,  81,  35,  88, 127, 329, 218, 271,
    291, 122, 132, 322,   4, 296,  30, 155,  46, 177,  73, 269, 304, 237, 294, 179,
    116, 242, 277, 161,  27, 332,   3, 281, 103,  23, 260, 162,   7,  77,  44, 295,
    120, 131,   9,  41, 339,  47, 301, 195, 220, 148, 101,  13, 175,  45, 178, 300,
    204, 184,  56, 128,  40,  54, 307, 321, 290,  65,  91,   5, 338, 130, 216,  99,
    345, 243,  70,  29, 125, 166, 244, 147, 171, 252, 268, 126, 138, 334, 165,  80,
    104,  50,  83, 205, 163, 253, 160, 351, 113, 343, 306, 180,  97, 100,  22, 280,
    181,  26,   1, 196, 262,  63, 293, 188, 340, 211, 215,  49, 136, 105, 213, 121,
    223, 173, 169,  96,  10,  71, 238, 112, 335, 114, 261,  12, 183,  60, 102,  95,
    266, 248,  11, 159, 319, 308, 297, 265,  57,  85, 270, 346, 109,  55, 230, 323,
     31, 251, 357, 356, 198, 331, 284, 267, 199, 347,  76,  39, 327, 107,  32, 289,
    352,  20, 156, 258, 206, 212, 108,  53, 311, 353, 354, 226, 152, 154, 342, 139,
      2, 326, 315, 350, 123, 185,  93, 288, 234,  67, 134, 137, 286,  98, 278, 254,
    310, 314, 135, 257,  38, 263, 249, 273,  24, 146, 298, 303, 119,   6, 182, 133,
    344, 110,  62, 283, 117, 141, 228, 264,  87, 191,  37,  43, 325, 333, 164, 221,
     94, 229, 187, 197, 217, 320,  89,  72,  69,  21, 186,  58, 167,  92, 189, 299,
     61, 106, 241,  79, 250,  36, 150, 174,  15,  48, 202, 272,  86,  34, 222, 225,
    324, 274, 219, 285, 129,  51, 239, 305, 172, 318,  17, 336, 115, 233, 142, 316,
    231, 192, 341, 328,  52, 145, 208,  64,  84, 207, 190, 118, 194,  19, 124,  68,
    302, 287, 282, 312, 330, 227, 235, 348, 246, 276,  59, 247,  75, 170, 256, 275,
    201, 209, 140, 309, 143
];

def sbox_combine(s0, s1):
    temp = [0]*len(s0)
    for i in range(len(s0)):
        temp[i] = s0[s1[i]]
    return(temp)

def sbox_repeat(s, e):
    result = [x for x in range(len(s))];
    while e:
        if e % 2:
            result = sbox_combine(result, s)
        s = sbox_combine(s, s)
        e = e / 2
    return(result);

def gen4(name):
    # convert name to number eg: "AAAA" -> 0x41414141
    name_num = 0;
    for char in name:
        name_num = name_num*256 + ord(char)
    #print "name_num: ", name_num;
    dst = sbox_repeat(sbox0, name_num) 
    #print "working with: ", dst

    relations = []
    serial = 1

    # solve src^x = sbox0^name_num

    # for each place in the destination sbox
    for spot in xrange(1,len(dst)):
        # print "on spot: ", spot
        # try exponents on the source sbox until it is hit
        for exp in range(1000):
            if dst[spot] == sbox_repeat(src, exp)[spot]:
                break

        # try exponents on source sbox until loops around
        for exp2 in xrange(2,1000):
            if src[spot] == sbox_repeat(src, exp2)[spot]:
                if (exp2-1 > 1) and ([exp2-1,exp] not in relations):
                    #print "appending relation[", exp2-1, ",", exp, "])"
                    relations.append([exp2-1, exp])
                break;

    #print "relations: ", relations
    serial = crt(relations)

    #print "output: ", sbox_repeat(src, serial)

    #if dst == sbox_repeat(src, serial):
    #    print "yes"
    #else:
    #    print "no"

    return "%d" % serial 

#------------------------------------------------------------------------------
# challenge 5
#------------------------------------------------------------------------------

g5_p = 6277101735386680763835789423207666416102355444459739541047
g5_a = 0;
g5_b = 3
g5_g = [5377521262291226325198505011805525673063229037935769709693,
    3805108391982600717572440947423858335415441070543209377693]
g5_o = 6277101735386680763835789423061264271957123915200845512077

def xgcd(x,y):
        a0=1; b0=0
        a1=0; b1=1

        if x<0:
                x *= -1
                a0 = -1
        if y<0:
                y *= -1
                b1 = -1

        if x<y:
                x,y,a0,b0,a1,b1 = y,x,a1,b1,a0,b0

        while 1:
                times = x/y
                x -= times*y
                a0 -= times*a1
                b0 -= times*b1
                if x==0:
                        break
                x,y,a0,b0,a1,b1 = y,x,a1,b1,a0,b0

        # x is 0, y is gcd
        return [y,a1,b1]

def invmod(x,p):
        [gcd,a,b] = xgcd(x,p)

        if gcd != 1:
		print x, " and ", p, " are not coprime!"
                raise ValueError()

        if a<0:
                a += p;

        return a

def g5_doublep(p1):
	x1,y1,z1 = p1[0],p1[1],p1[2]

	if z1==0:
		return p1
	if z1!=1:
		raise ValueError

	x3 = ((3*x1*x1) * invmod(2*y1, g5_p))**2 - 2*x1
	y3 = (3*x1*x1) * invmod(2*y1, g5_p)*(x1-x3) - y1

	x3 = x3 % g5_p
	y3 = y3 % g5_p

	return [x3,y3,1]

def g5_addp(p1,p2):
	x1,y1,z1,x2,y2,z2 = p1[0],p1[1],p1[2],p2[0],p2[1],p2[2]
	if p1==p2:
		return g5_doublep(p1)
	if x1==x2 and y1==(-y2 % g5_p):
		return [0,1,0]
	if z1==0:
		return p2
	if z2==0:
		return p1
	if z1!=1 or z2!=1:
		raise ValueError

	x3 = ((y2-y1)*invmod(x2-x1, g5_p))**2 - x1 - x2
	y3 = (y2-y1)*invmod(x2-x1, g5_p) * (x1-x3) - y1

	x3 = x3 % g5_p
	y3 = y3 % g5_p

	return [x3,y3,1]


def g5_mulp(p1,m):
	answer = [0,1,0]
	runner = p1

	while m:
		if m & 1:
			answer = g5_addp(answer, runner)

		runner = g5_addp(runner, runner)

		m = m/2

	return answer

def gen5(name):
	# convert name to point eg: "AAAA" -> (0x41414143, 0xe662156a98cd91e996c94473891707ba36dcc16702c65232)
	name_x = 0;
	for char in name:
	    name_x = name_x*256 + ord(char)
	while 1:
		quadres = (name_x**3 + 3)%g5_p
		name_y = pow(quadres, (g5_p+1)/4, g5_p)
		if pow(name_y, 2, g5_p) == quadres:
			break;
		name_x += 1
	P1 = [name_x, name_y, 1]

	#print "P1: %x-%x" % (P1[0], P1[1])
	
	serial = g5_mulp(P1, invmod(13, g5_o));

	return "%d-%d" % (serial[0], serial[1])

#------------------------------------------------------------------------------
# challenge 6
#------------------------------------------------------------------------------

ef_poly = [ 6927354994984596761, 
            3748481628317431011, 
            4620394961492627319, 
            5139526688006885996, 
            7434977584397438745, 
            5869627458528271108, 
            6614627009312766654, 
            7678097075714978717, 
            5204744523362322329, 
            9398406610703021891, 
            3699077701165988134, 
            4097988535177883106, 
            1 ]

p = 9524793152874449521

extension = 12

field_0 = [0]*extension
field_1 = [1]+[0]*(extension-1)
field_2 = [2]+[0]*(extension-1)
field_3 = [3]+[0]*(extension-1)

[a_1,a_2,a_3,a_4,a_6] = [field_0, field_0, field_0, field_0, [13]+[0]*(extension-1)]
ecc_0 = [field_0, field_1, field_0]
ecc_r = 9524793149788155121

ecc_g1 = [field_1, [4577206343548535956]+[0]*(extension-1), field_1]

ecc_g2 = [ [2582477270547956977, 2530023797852594208, 3239246275650681784, 9356115311475410715, 
            4925994372571715422, 9082757750092742366, 3946459769382694037, 9258625410126221791, 
            1546806533803993509, 7416446501236864153, 3476916985694553167,   28930072329430674 ],
           [ 544373368025887171, 8874621118513866374, 8009494946720473686, 1065433853209237195, 
            1956558743620835276, 7323759157123465679, 2253879482993753613, 3769727620341931341, 
            2471082114350274565,   53398003196643395,  392122047555439583, 4569041207989982512 ],
           field_1
         ]

ecc_P =  [ [6400173802196845754, 474243480778556212, 5936146128578535690, 1305341026780126317, 
            832499822664426562, 5522347192587339249, 6887819078187130363, 7183243026634094341, 
            5513000999900352828, 6346523241154805362, 7779915664763212307, 9234041514029458289 ],
           [122495515023342804, 6985863117841018225, 171210160812342620, 8053089739653482422, 
            318194623178172360, 8111126461946895687, 915090504523216963, 5152204995298522178, 
            212427926173001815, 359467867455554913, 3816268899954016796, 4965553112357672903 ],
            field_1
         ]
#------------------------------------------------------------------------------
# PRIME FIELD OPS
#------------------------------------------------------------------------------
def pf_add(a,b):
    return (a+b) % p

def pf_inva(a):
    return (-a) % p

def pf_sub(a,b):
    return pf_add(a, pf_inva(b))

def pf_mul(a,b):
    return a*b % p

def pf_pow(a,e):
    result = 1
    runner = a
    while e:
        if e%2:
            result = pf_mul(result, runner)
        runner = pf_mul(runner, runner)
        e = int(e/2)
    return result

def pf_invm(a):
    b = p
    equ_a = 1
    equ_b = 0
    while 1:
        n = a / b
        a = a - n*b
        equ_a = equ_a - n*equ_b
        if a==1:
            if equ_a < 0: equ_a += p
            return equ_a
        [a, equ_a, b, equ_b] = [b, equ_b, a, equ_a]

def pf_div(a,b):
    return pf_mul(a, pf_invm(b))

def polyring_sub(a,b):
    while len(a) < len(b): a = a + [0]
    while len(b) < len(a): b = b + [0]
    r = [0]*len(a)
    for i in range(len(a)):
        r[i] = (a[i] - b[i]) % p
    return r

def polyring_mul(a,b):
    len_a = len(a)
    len_b = len(b)    
    r = [0]*(len_a + len_b - 1)
    for i in range(len_a):
        for j in range(len_b):
            r[j+i] = (r[j+i] + a[i]*b[j]) % p
    return r

def polyring_div(a,b):
    q = []
    while a[-1:] == [0]: a = a[0:-1]    
    while b[-1:] == [0]: b = b[0:-1]
    width = len(b)

    big_c = pf_invm(b[-1:][0])
    while len(a) >= width:
        t = a[-width:]
        c = pf_mul(t[-1:][0], big_c)
        q = [c]+q
        for i in range(width):
            t[i] = pf_sub(t[i], pf_mul(c,b[i]))
        a = a[0:-width] + t[0:-1]
    while len(q) < len(b): q = q + [0]
    return [q,a]

def ef_add(a,b):
    degree = len(a)
    r = [0]*degree
    for i in range(degree):
        r[i] = (a[i] + b[i]) % p
    return r

def ef_mul(a,b):
    degree = len(a)

    if degree != len(b):
        print "a: %s" % a
        print "b: %s" % b
        raise ValueError("incoming elements not from same field!")
    if degree != len(ef_poly)-1:
        raise ValueError("incoming elements incompatible with reduction poly!")

    r = polyring_mul(a,b)
    r = polyring_div(r,ef_poly)[1]
    if len(r) < extension: r = r + [0]*(extension - len(r))
    return r

def ef_inva(a):
    result = [pf_inva(x) for x in a]
    return result

def ef_sub(a,b):
    return ef_add(a, ef_inva(b))
    
def ef_pow(a,e):
    degree = len(a)
    result = [1]+[0]*(degree-1)
    runner = a
    while(e):
        if(e % 2):
            result = ef_mul(result, runner)
        runner = ef_mul(runner, runner)
        e = int(e/2);
    return result

def ef_invm(a):
    b = ef_poly
    equ_a = field_1
    equ_b = field_0
    while 1:
        #print "dividing %s by %s" % (a,b)
        [n,a] = polyring_div(a, b)
        #print "polyring_div returned: %s", n
        equ_a = polyring_sub(equ_a, polyring_mul(n,equ_b))
        # is constant result?
        if a[0] and (len(a)==1 or sum(1 for x in a if x>1)==1):
            # make monic?
            if a[0] != 1: 
                equ_a = polyring_mul(equ_a, [pf_invm(a[0])])
            return equ_a[0:extension]
        [a, equ_a, b, equ_b] = [b, equ_b, a, equ_a]

def ef_div(a,b):
    return ef_mul(a,ef_invm(b))

def ecc_add(A,B):
    [x1,y1,z1] = A
    [x2,y2,z2] = B
    if z1==field_0: return B
    if z2==field_0: return A
    if x1==x2 and y1==ef_inva(y2): return ecc_0
    if A==B:
        slope = ef_div(ef_add(ef_mul(field_3, ef_mul(x1,x1)), a_4), ef_mul(field_2, y1))
    else:
        slope = ef_div(ef_sub(y2,y1), ef_sub(x2, x1))
    x3 = ef_sub(ef_sub(ef_mul(slope, slope), x1), x2)
    y3 = ef_sub(ef_mul(slope, ef_sub(x1, x3)), y1)
    return [x3,y3,field_1]    

def ecc_inv(A):
    if A[2]==0: return A
    return [A[0], ef_inva(A[1]), A[2]]

def ecc_mul(A,n):
    result = ecc_0
    runner = A
    while n:
        if n%2:
            result = ecc_add(result, runner)
        runner = ecc_add(runner, runner)
        n = int(n/2)
    return result


def gen6(name):
    # convert name to point in r-torsion
    name_c = 0;
    for char in name:
        name_c = name_c*256 + ord(char)
    ecc_M = ecc_mul(ecc_g1, name_c)
    ecc_S = ecc_mul(ecc_M,1223334444333221111)
    return "%s-%s" % (ecc_S[0][0], ecc_S[1][0])

#------------------------------------------------------------------------------
# main
#------------------------------------------------------------------------------
names = ('AcidBurn', 'ZeroCool', 'CerealKiller', 'CrashOverride', 'PhantomPhreak', 'a', 'andrew');

if len(sys.argv) == 2:
    names = (sys.argv[1])

for func in (gen6, gen1, gen2, gen3, gen4, gen5, gen6):
	print func.func_name, ":\n--------\n"
	for name in names:
		print "#  %16s %s" % (name, func(name));

