// 2/2008 andrewl

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>

#include "funbytetools.h"

using namespace std;

unsigned char prolog[] =
{
  0x55,                                           //00 push    ebp
  0x8B, 0xEC                                      //01 mov     ebp,esp
};

unsigned char epilog[] =
{
  0x5D,                                           //00 pop     ebp
  0xC3                                            //01 ret
};

// 18 long
// doll[0x06] == byte index into serial
// doll[0x09] == byte ebp offset of variable to set true
// doll[0x0C] == required character
// doll[0x11] == what to set var to
unsigned char doll[] =
{
  0x8B, 0x45, 0x08,                               //00: mov     eax,dword ptr [ebp+8]
  0x0F, 0xB6, 0x48, 0x01,                         //03: movzx   ecx,byte ptr [eax+1]
  0x8B, 0x55, 0x0C,                               //07: mov     edx,dword ptr [ebp+0Ch]
  0x83, 0xF9, 0x41,                               //0A: cmp     ecx,41h
  0x75, 0x03,                                     //0D: jne     algo!dollz+0x17
  0xC6, 0x02, 0x01,                               //0F: mov     byte ptr [edx],1
};

// 21 long
// zero[0x08] == distance up to target code from this function+5
// zero[0x0F] == dword size to zero
unsigned char zero[] =
{
  0xE8, 0x00, 0x00, 0x00, 0x00,                   //00: call    algo!lala+0x9 (00401049)
  0x5F,                                           //05: pop     edi
  0x81, 0xEF, 0x78, 0x56, 0x34, 0x12,             //06: sub     edi,12345678h
  0x32, 0xC0,                                     //0C: xor     al,al
  0xB9, 0x29, 0x00, 0x00, 0x00,                   //0E: mov     ecx,29h
  0xF3, 0xAA,                                     //13: rep stos byte ptr es:[edi]
};

// 26 long
// crypt1[0x08] == distance down to code to decrypt from this function+5
// crypt1[0x0D] == dword size to crypt
// crypt1[0x13] == char xor key
unsigned char crypt1[] =
{
  0xE8, 0x00, 0x00, 0x00, 0x00,                   //00: call    algo!lala+0x9 (00401049)
  0x5E,                                           //05: pop     esi
  0x81, 0xC6, 0x67, 0x45, 0x23, 0x01,             //06: add     esi,1234567h
  0xB9, 0x29, 0x00, 0x00, 0x00,                   //0C: mov     ecx,29h
  0x80, 0x36, 0x77,                               //11: xor     byte ptr [esi],77h
  0x46,                                           //14: inc     esi
  0x83, 0xE9, 0x01,                               //15: sub     ecx,1
  0x75, 0xF7                                      //18: jne     algo!encrypt1+0x1d (0041194d)
};

struct DOLLINFO
{
    DOLLINFO()
    {
        index=chMatch=bVal=0;
    }

    DOLLINFO(char a, char b, char c)
    {
        index=a;
        chMatch=b;
        bVal=c;
    }

    unsigned char   index;
    unsigned char   chMatch;
    unsigned char   bVal;
};

#define SIZE_REGION 102400
#define NUM_DOLLS 1538

int hasFreeSpots(DOLLINFO *pDolls)
{
    for(int i=0; i<NUM_DOLLS; ++i)
        if(pDolls[i].chMatch==0)
            return 1;

    return 0;
}

int findRandomFreeSpot(DOLLINFO *pDolls, int startingAt)
{
    vector<unsigned int> freeSpots;

    // count free spots
    for(int i=startingAt; i<NUM_DOLLS; ++i)
        if(pDolls[i].chMatch==0)
            freeSpots.push_back(i);

    if(freeSpots.size() == 0)
        return -1;
    else
        return freeSpots.at(rand()%freeSpots.size());
}


int main(int argc, char * argv[])
{
    unsigned char       *code, *pCode;


    // setup
    srand(time(NULL));


    struct DOLLINFO    *dollInfos = new struct DOLLINFO[NUM_DOLLS];

                                        // "CRaCkMEs" or "14285714"
    dollInfos[1530] = DOLLINFO(0, 'C', 1);      // first char can be a 'C' or '1'
    dollInfos[354] = DOLLINFO(0, 'C', 0);
    dollInfos[322] = DOLLINFO(0, '1', 1);
    dollInfos[128] = DOLLINFO(0, '1', 0);

    dollInfos[983] = DOLLINFO(1, 'R', 1);       // second char can be 'R' or '4'
    dollInfos[425] = DOLLINFO(1, 'R', 0);
    dollInfos[1529] = DOLLINFO(1, '4', 1);
    dollInfos[999] = DOLLINFO(1, '4', 0);

    dollInfos[1422] = DOLLINFO(2, 'a', 1);      // third char can be 'A' or '2'
    dollInfos[325] = DOLLINFO(2, 'a', 1);
    dollInfos[352] = DOLLINFO(2, '2', 1);
    dollInfos[1222] = DOLLINFO(2, '2', 1);

    dollInfos[955] = DOLLINFO(3, 'C', 1);       // fourth char can be 'C' or '8'
    dollInfos[1513] = DOLLINFO(3, 'C', 1);
    dollInfos[824] = DOLLINFO(3, '8', 1);
    dollInfos[193] = DOLLINFO(3, '8', 1);

    dollInfos[1142] = DOLLINFO(4, 'k', 1);      // fifth char can be 'K' or '5'
    dollInfos[626] = DOLLINFO(4, 'k', 0);
    dollInfos[724] = DOLLINFO(4, '5', 1);
    dollInfos[292] = DOLLINFO(4, '5', 0);

    dollInfos[442] = DOLLINFO(5, 'M', 1);       // sixth char can be 'M' or '7'
    dollInfos[326] = DOLLINFO(5, 'M', 0);
    dollInfos[224] = DOLLINFO(5, '7', 1);
    dollInfos[12] = DOLLINFO(5, '7', 0);

    dollInfos[952] = DOLLINFO(6, 'E', 1);       // seventh char can be 'E' or '1'
    dollInfos[136] = DOLLINFO(6, 'E', 1);
    dollInfos[834] = DOLLINFO(6, '1', 1);
    dollInfos[922] = DOLLINFO(6, '1', 1);

    dollInfos[142] = DOLLINFO(7, 's', 1);       // eighth char can be 'S' or '4'
    dollInfos[936] = DOLLINFO(7, 's', 1);
    dollInfos[624] = DOLLINFO(7, '4', 1);
    dollInfos[192] = DOLLINFO(7, '4', 1);


    while(hasFreeSpots(dollInfos))
    {
        unsigned int spot1=-1;
        unsigned int spot2=-1;

        while(spot2==-1)
        {
            spot1 = findRandomFreeSpot(dollInfos, 0);
            spot2 = findRandomFreeSpot(dollInfos, spot1+1);
        }

        unsigned char chRandom;
        unsigned char iRandom;


        // generate chars that are not the true checked ones
        do
        {
            switch(rand()%3)
            {
                case 0:
                    chRandom = 48 + rand()%10;
                    break;
                case 1:
                    chRandom = 65 + rand()%26;
                    break;
                case 2:
                    chRandom = 97 + rand()%26;
                    break;
            }

            iRandom = 0xFF & (rand()%8);

        } while(    (iRandom==0 && (chRandom=='C' || chRandom=='1')) ||
                    (iRandom==1 && (chRandom=='R' || chRandom=='4')) ||
                    (iRandom==2 && (chRandom=='a' || chRandom=='2')) ||
                    (iRandom==3 && (chRandom=='C' || chRandom=='8')) ||
                    (iRandom==4 && (chRandom=='k' || chRandom=='5')) ||
                    (iRandom==5 && (chRandom=='M' || chRandom=='7')) ||
                    (iRandom==6 && (chRandom=='E' || chRandom=='1')) ||
                    (iRandom==7 && (chRandom=='s' || chRandom=='4'))        );

        // spot1 sets true, later counteracted by spot2 check
        dollInfos[spot1] = DOLLINFO(iRandom, chRandom, 1);
        dollInfos[spot2] = DOLLINFO(iRandom, chRandom, 0);

        //printf("at %d if(serial[%d]=='%c') b%d=%d\n", spot1, dollInfos[spot1].index, dollInfos[spot1].chMatch,
                                //dollInfos[spot1].index, dollInfos[spot1].bVal);
        //printf("at %d if(serial[%d]=='%c') b%d=%d\n", spot2, dollInfos[spot2].index, dollInfos[spot2].chMatch,
                                //dollInfos[spot2].index, dollInfos[spot2].bVal);
    }

    // aloc region
    code = new unsigned char[SIZE_REGION];
    memset(code, 0x90, SIZE_REGION);

    // point to end
    pCode = code+SIZE_REGION;
    unsigned char       *pchEnd = pCode;

    // write epilog
    pCode -= sizeof(epilog);
    memcpy(pCode, epilog, sizeof(epilog));
    unsigned char       *pchEpilog = pCode;
    
    for(int x=NUM_DOLLS-1; x>=0; --x)
    {
        int     iSerial = 1;
        char    chRequired = 'A';
        int     iBoolVarIndex = 1;

        char    chXorKey = (rand()%255) +1;

        // write zero'er
        pCode -= sizeof(zero);
        memcpy(pCode, zero, sizeof(zero));
        unsigned char       *pchZero = pCode;
        
        // fixup zero'er
        *(unsigned long *)(pCode+0x08) = sizeof(doll)+5;            // distance up to zero
        *(unsigned char *)(pCode+0x0F) = sizeof(doll);              // size to zero

        // write doll
        pCode -= sizeof(doll);
        memcpy(pCode, doll, sizeof(doll));
        unsigned char       *pchDoll = pCode;

        // fixup doll
        *(unsigned char *)(pCode+0x06) = dollInfos[x].index;            // byte index into serial
        *(unsigned char *)(pCode+0x09) = 0x0C + 4*dollInfos[x].index;   // byte ebp offset of variable
        *(unsigned char *)(pCode+0x0C) = dollInfos[x].chMatch;          // character to compare against
        *(unsigned char *)(pCode+0x11) = dollInfos[x].bVal;             // true or false

        // encrypt region
        for(int i=0; i<pchEnd-pchDoll; ++i)
        pCode[i] ^= chXorKey;

        // write decryptor
        pCode -= sizeof(crypt1);
        memcpy(pCode, crypt1, sizeof(crypt1));
        unsigned char       *pchCrypter = pCode;

        // fixup decryptor
        *(unsigned long *)(pCode+0x08) = sizeof(crypt1)-5;          // distance down to start decrypter
        *(unsigned long *)(pCode+0x0D) = (pchEnd-pchDoll);          // number of bytes to decrypt
        *(unsigned char *)(pCode+0x13) = chXorKey;                  // decryption key
    }
  
    // write prolog
    pCode -= sizeof(prolog);
    memcpy(pCode, prolog, sizeof(prolog));
    unsigned char       *pchProlog = pCode;

    printBytesAsCByteArray(pCode, pchEnd-pCode, "bytesVerifySerial");


    //printf("Wrote %d bytes of doll code!\n", pchEnd - pCode);

    /*
    typedef void (*PDOLLFUNC)(unsigned char *, char * b1, char * b2, char * b3, char * b4, char * b5, char * b6, char * b7, char * b8);

    PDOLLFUNC pDollFunc = (PDOLLFUNC)pCode;

    char b0, b1, b2, b3, b4, b5, b6, b7;
    unsigned char serial[] = "serial";

    pDollFunc((unsigned char *)argv[1], &b0, &b1, &b2, &b3, &b4, &b5, &b6, &b7);

    if(b0 && b1 && b2 && b3 && b4 && b5 && b6 && b7)
        //printf("PASS!\n");
    else
        //printf("FAIL!\n");
    */

    delete [] code;
    delete [] dollInfos;
}
