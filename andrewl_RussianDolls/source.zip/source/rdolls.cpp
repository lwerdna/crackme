#include <windows.h>
#include <windowsx.h>

// local includes
#include "bytesVerifySerial.h"
#include "russresource.h"

// lib includes
#include "ufmod.h"

// defines
#define WIDTH_WINDOW 264
#define HEIGHT_WINDOW 43

#define WIDTH_EDIT 132
#define HEIGHT_EDIT 14

// typedef crap
typedef void (*PDOLLFUNC)(unsigned char *, char * b1, char * b2, char * b3, char * b4, char * b5, char * b6, char * b7, char * b8);

// globals
HANDLE  g_hbmBackground = NULL;
HWND    g_hWnd;
HWND    g_hEdit;
HANDLE  g_hHeap;

long __stdcall WindowProcedure(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HDC hdc = NULL;
    HDC hdcMem = NULL;
    HBITMAP hbmOld = NULL;
    PAINTSTRUCT ps = {0};

    BITMAP bm;

    int xPos;
    int yPos;

    POINT coords;

    switch(msg)
    {
        // our edit control sends this message to ask us what color he should darw the background
        case WM_CTLCOLOREDIT:
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, RGB(255, 255, 255));
            return (LRESULT)GetStockObject(BLACK_BRUSH);

        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
            coords.x = GET_X_LPARAM(lParam);
            coords.y = GET_Y_LPARAM(lParam);

 
            if(coords.y >= 2 && coords.y <= 8 && coords.x >= 2 && coords.x <= 9)
                PostMessage(hWnd, WM_CLOSE, 0, 0);
            else
                MessageBox( NULL,
                        "http://andrewl.us\n"
                        "http://www.crackmes.de\n\n"
                        "Music by glue_master!\n"
                        "http://www.modarchive.com\n",
                        "Russian Dolls CrackME",
                        MB_OK   );

            break;

        case WM_KEYUP:
            if(wParam == VK_ESCAPE)
                SendMessage(hWnd, WM_CLOSE, (WPARAM)NULL, (LPARAM)NULL);
            
            break;

        case WM_COMMAND:
            if(HIWORD(wParam) == EN_CHANGE)
            {
                LRESULT        len;
                unsigned char  buffer[256];
                len = SendMessage(g_hEdit, WM_GETTEXT, 256, (LPARAM)buffer);

                if(len==8)
                {
                    char a,b,c,d,e,f,g,h;
                    //unsigned char * pchTemp = new unsigned char[sizeof(bytesVerifySerial)];
                    void * pchTemp = HeapAlloc(g_hHeap, 0, sizeof(bytesVerifySerial));
                    memcpy(pchTemp, bytesVerifySerial, sizeof(bytesVerifySerial));
                    PDOLLFUNC pfnVerifySerial = (PDOLLFUNC)pchTemp;
                    
                    pfnVerifySerial(buffer, &a, &b, &c, &d, &e, &f, &g, &h);
                    if(a && b && c && d && e && f && g && h)
                        MessageBoxA(NULL, "Congratulations!", "Status", MB_OK);
                    else
                        MessageBoxA(NULL, "Sorry, try harder!", "Status", MB_OK);

                    //delete [] pchTemp;
                    HeapFree(g_hHeap, 0, pchTemp);
                }
            }

            break;

        case WM_CREATE:
            //g_hbmBackground = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(1));
            g_hbmBackground = LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(1), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR);

            if(g_hbmBackground == NULL)
                MessageBox(hWnd, "Could not load images!", "Error", MB_OK | MB_ICONEXCLAMATION);

            // center window
            {
                UINT    xRes=0, yRes=0;

                xRes=GetDeviceCaps(GetDC(NULL), HORZRES);
                yRes=GetDeviceCaps(GetDC(NULL), VERTRES);

                SetWindowPos(hWnd, HWND_TOP, (xRes-WIDTH_WINDOW)/2, (yRes-HEIGHT_WINDOW)/2, WIDTH_WINDOW, HEIGHT_WINDOW, 0);
            }

            // load child edit window

            break;

        case WM_CLOSE:
            DestroyWindow(hWnd);
            break;

        case WM_DESTROY:
            DeleteObject(g_hbmBackground);
            PostQuitMessage(0);
            break;

        // windows is asking what is under cursor of a click - we return that it's always caption
        // so popup window will be movable
        case WM_NCHITTEST:        
            coords.x = GET_X_LPARAM(lParam);
            coords.y = GET_Y_LPARAM(lParam);
            ScreenToClient(hWnd, &coords);
 
            if(coords.y >= 2 && coords.y <= 8 && coords.x >= 2 && coords.x <= 9)
                return HTCLIENT;
            
            if(coords.x <248 || coords.x > 255)
                return HTCAPTION;
            
            return HTCLIENT;

            break;

        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);

            hdcMem = CreateCompatibleDC(hdc);
            hbmOld = (HBITMAP) SelectObject(hdcMem, (HGDIOBJ)g_hbmBackground);

            // info about background bitmap into bm
            GetObject(g_hbmBackground, sizeof(bm), &bm);

            // 
            BitBlt(hdc, 0, 0, 382, 128, hdcMem, 0, 0, SRCCOPY);

            SelectObject(hdcMem, hbmOld);
            DeleteDC(hdcMem);

            EndPaint(hWnd, &ps);
            break;

        default:
            return DefWindowProc(hWnd, msg, wParam, lParam);
    }

    return 0;
}

void EntryPoint()
{
    HWAVEOUT * phWaveOut;
    phWaveOut = uFMOD_PlaySong(MAKEINTRESOURCE(ID_XMFILE), 0, XM_RESOURCE);

    g_hHeap = GetProcessHeap();

    HINSTANCE hInstance = GetModuleHandle(0);

    WNDCLASSEX          wcx={0};

    wcx.cbSize        = sizeof(WNDCLASSEX);
    wcx.style         = 0;
    wcx.lpfnWndProc   = WindowProcedure;
    wcx.cbClsExtra    = 0;
    wcx.cbWndExtra    = 0;
    wcx.hInstance     = hInstance;
    wcx.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));
    wcx.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wcx.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    wcx.lpszMenuName  = NULL;
    wcx.lpszClassName = "WC_RUSSIAN_DOLLS";
    wcx.hIconSm       = LoadIcon(hInstance, MAKEINTRESOURCE(ID_ICON));

    RegisterClassEx(&wcx);

    // create window
    g_hWnd = CreateWindowEx(
        0,                      // dwExStyle
        "WC_RUSSIAN_DOLLS",     // class
        "\"Russian Dolls\" CrackME",        // title
        WS_POPUP,               // style
        0,                      // location x
        0,                      // location y
        WIDTH_WINDOW,           // width
        HEIGHT_WINDOW,          // height
        NULL,                   // hWndParent
        NULL,                   // hMenu
        hInstance,              // hInstance
        NULL                    // lParam
    );

    // create child window
    g_hEdit = CreateWindowEx(
                    0,                      // dwExStyle
                    "EDIT",                 // class
                    0,               // title
                    ES_CENTER|WS_CHILD|WS_VISIBLE|!WS_BORDER,              // style
                    66,                      // location x
                    13,                      // location y
                    WIDTH_EDIT,           // width
                    HEIGHT_EDIT,          // height
                    g_hWnd,                   // hWndParent
                    NULL,                   // hMenu
                    hInstance,              // hInstance
                    NULL                    // lParam
                    );

    SendMessage(g_hEdit, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), FALSE);
    SendMessage(g_hEdit, WM_SETTEXT, 0, (LPARAM)"8-DiGiT SERiAL");

    ShowWindow(g_hWnd, SW_SHOW);

    // process messages
    MSG     msg;

    while(GetMessage(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    uFMOD_StopSong();

    CloseHandle(*phWaveOut);

    ExitProcess(msg.wParam);
}
