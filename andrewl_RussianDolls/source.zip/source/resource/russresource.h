#define ID_BITMAP 1
#define ID_ICON 2
#define ID_XMFILE 3
