// windbg extension to read bignums and ecc points in Numernia's "keygenme tre" keygenme
// 2010 andrewl

#include <windows.h>
#include <dbgeng.h>

// miracl stuff
extern "C"
{
#include "c:\code\lib\miracl5.3.3\include\miracl.h"
}
#pragma comment(lib, "c:\\code\\lib\\miracl5.3.3\\ms32.lib")
#pragma comment(linker, "/NODEFAULTLIB:libc.lib")

// globals
miracl * mip;

PDEBUG_CONTROL4 control=0;
PDEBUG_CLIENT4 client=0;
PDEBUG_DATA_SPACES3 dataspaces = 0;

//
//
void DllMain()
{
}

//
//
// DEBUG INTERFACE STUFF
//
// 

BOOL GetInterfaces(PDEBUG_CLIENT4 pclient)
{
    BOOL bRet=0;

    client = pclient;
    if(!client)
        if(DebugCreate(__uuidof(IDebugClient4), (PVOID *)&client) != S_OK)
            goto cleanup;

    if(client->QueryInterface(__uuidof(IDebugControl3), (PVOID *)&control) != S_OK)
        goto cleanup;

    if(client->QueryInterface(__uuidof(IDebugDataSpaces3), (PVOID *)&dataspaces) != S_OK)
        goto cleanup;

    bRet=1;
    cleanup:
    return bRet;
}

VOID ReleaseInterfaces()
{
    if(dataspaces)
    {
        dataspaces->Release();
        dataspaces=0;
    }

    if(control)
    {
        control->Release();
        control=0;
    }

    if(client)
    {
        client->Release();
        client=0;
    }
}

//
//
// DEBUG CALLBACK NOTIFICATIONS
//
// 

extern "C" HRESULT __stdcall DebugExtensionInitialize(PULONG Version, PULONG Flags)
{
    HRESULT hFuncRet=E_FAIL;

    if(!GetInterfaces(0))
        goto cleanup;

    control->Output(DEBUG_OUTPUT_NORMAL,"extension: initializing...\n");

    *Version = DEBUG_EXTENSION_VERSION(1, 0);
    *Flags = 0;

    // init miracl
    mip = mirsys(100, 16);
    mip->IOBASE = 16;

    hFuncRet = S_OK;

    cleanup:
    ReleaseInterfaces();
    return hFuncRet;
}

extern "C" VOID __stdcall DebugExtensionUninitialize(void)
{
    if(!GetInterfaces(0))
        goto cleanup;

    control->Output(DEBUG_OUTPUT_NORMAL,"extension: uninitializing...\n");

    cleanup:
    ReleaseInterfaces();
}

extern "C" VOID WINAPI DebugExtensionNotify(ULONG Notify, ULONG64 Argument)
{
    if(!GetInterfaces(0))
        goto cleanup;

    switch(Notify)
    {
        case DEBUG_NOTIFY_SESSION_ACTIVE:
            //control->Output(DEBUG_OUTPUT_NORMAL,"extension: got DEBUG_NOTIFY_SESSION_ACTIVE\n");
            break;

        case DEBUG_NOTIFY_SESSION_INACTIVE:
            //control->Output(DEBUG_OUTPUT_NORMAL,"extension: got DEBUG_NOTIFY_SESSION_INACTIVE\n");
            break;

        case DEBUG_NOTIFY_SESSION_ACCESSIBLE:
            //control->Output(DEBUG_OUTPUT_NORMAL,"extension: got DEBUG_NOTIFY_SESSION_ACCESSIBLE\n");
            break;

        case DEBUG_NOTIFY_SESSION_INACCESSIBLE:
            //control->Output(DEBUG_OUTPUT_NORMAL,"extension: got DEBUG_NOTIFY_SESSION_INACCESSIBLE\n");
            break;
    }

    cleanup:
    ReleaseInterfaces();
}

//
//
// REAL BIGNUM WORK NOW
//
//

typedef struct _NUMERNIABIG {
    PULONG  pDwords;
    ULONG   len;
} NUMERNIABIG, *PNUMERNIABIG;

typedef struct _NUMERNIAECCPOINT {
    PNUMERNIABIG x;
    PNUMERNIABIG y;
} NUMERNIAECCPOINT, *PNUMERNIAECCPOINT;

VOID __stdcall PrintBnAtAddr(UINT64 pBig, INT base)
{
    NUMERNIABIG m;
    DWORD dwRet;
    CHAR buff[256];

    // read in the number structure
    // 
    if(S_OK != dataspaces->ReadVirtual(pBig, &m, (ULONG)sizeof(NUMERNIABIG), &dwRet))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: reading memory from target @%08X\n", pBig);
        goto cleanup;
    }

    // verbose stuff
    //
    if(m.len > 64)
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: over 128 coefficients, likely this is not a bignum!\n");
        goto cleanup;
    }

    // read in digits array
    //
    PBYTE pBytes = new UCHAR[m.len * 4];

    if(S_OK != dataspaces->ReadVirtual((ULONG64)m.pDwords, pBytes, m.len * 4, &dwRet))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: reading memory from target @\n", m.pDwords);
        goto cleanup;
    }

    // byte array into miracl type
    INT oldBase = mip->IOBASE;
    mip->IOBASE = base;

    big b = mirvar(0);

    // miracl's bytes_to_big expect most significant byte first
    for(INT i=0; i<2*m.len; ++i)
    {
        BYTE temp=pBytes[i];
        pBytes[i]=pBytes[4*m.len-1-i];
        pBytes[4*m.len-1-i]=temp;
    }

    bytes_to_big(4*m.len, (PCHAR)pBytes, b);
    cotstr(b, buff);
    control->Output(DEBUG_OUTPUT_NORMAL, "%s", buff);

    mip->IOBASE = oldBase;

    cleanup:
    if(pBytes)
        delete pBytes;
    
    return;
}

HRESULT __stdcall bn(PDEBUG_CLIENT4 Client, PCSTR arg)
{
    // VARS: general
    HRESULT hRes = E_FAIL;
    NUMERNIABIG m;
    DWORD dwRet = 0;

    // VARS: other    
    UINT64 pBig = 0;

    // get interfaces
    //
    if(!GetInterfaces(0))
        goto cleanup;

    // get arg
    //
    DEBUG_VALUE pdv;

    memset(&pdv,0,sizeof(pdv));

    if(S_OK != control->Evaluate(arg, DEBUG_VALUE_INT64, &pdv, 0))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: evaluating argument\n");
        goto cleanup;
    }

    pBig = pdv.I64;

    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "bignum @%08X\n", pBig);

    // read in the number structure
    // 
    if(S_OK != dataspaces->ReadVirtual(pBig, &m, (ULONG)sizeof(NUMERNIABIG), &dwRet))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: reading memory from target @%08X\n", pBig);
        goto cleanup;
    }

    // verbose stuff
    //
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "    len=%d\n", m.len);
    control->Output(DEBUG_OUTPUT_NORMAL, "pdwords=%08X\n", m.pDwords);

    if(m.len > 64)
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: over 128 coefficients, likely this is not a bignum!\n");
        goto cleanup;
    }

    // print in decimal and hex
    //
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "hex: ");
    PrintBnAtAddr(pBig, 16);
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "dec: ");
    PrintBnAtAddr(pBig, 10);
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");

    control->Output(DEBUG_OUTPUT_NORMAL, "\n");

    // done!
    //
    hRes = S_OK;

    cleanup:
    ReleaseInterfaces();
    return hRes;
}

HRESULT __stdcall point(PDEBUG_CLIENT4 Client, PCSTR arg)
{
    // VARS: general
    HRESULT hRes = E_FAIL;
    NUMERNIAECCPOINT m;
    DWORD dwRet = 0;

    // VARS: other    
    UINT64 pPoint = 0;

    // get interfaces
    //
    if(!GetInterfaces(0))
        goto cleanup;

    // get arg
    //
    DEBUG_VALUE pdv;

    memset(&pdv,0,sizeof(pdv));

    if(S_OK != control->Evaluate(arg, DEBUG_VALUE_INT64, &pdv, 0))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: evaluating argument\n");
        goto cleanup;
    }

    pPoint = pdv.I64;

    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "bignum @%08X\n", pPoint);

    // read in the point structure
    // 
    if(S_OK != dataspaces->ReadVirtual(pPoint, &m, (ULONG)sizeof(NUMERNIAECCPOINT), &dwRet))
    {
        control->Output(DEBUG_OUTPUT_ERROR, "ERROR: reading memory from target @%08X\n", pPoint);
        goto cleanup;
    }

    // verbose stuff
    //
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "*x: %08X\n", m.x);
    control->Output(DEBUG_OUTPUT_NORMAL, "*y: %08X\n", m.y);

    // print in decimal and hex
    //
    control->Output(DEBUG_OUTPUT_NORMAL, "\n");
    control->Output(DEBUG_OUTPUT_NORMAL, "hex: [");
    PrintBnAtAddr((UINT64)m.x, 16);
    control->Output(DEBUG_OUTPUT_NORMAL, ", ");
    PrintBnAtAddr((UINT64)m.y, 16);
    control->Output(DEBUG_OUTPUT_NORMAL, "]\n");

    control->Output(DEBUG_OUTPUT_NORMAL, "dec: [");
    PrintBnAtAddr((UINT64)m.x, 10);
    control->Output(DEBUG_OUTPUT_NORMAL, ", ");
    PrintBnAtAddr((UINT64)m.y, 10);
    control->Output(DEBUG_OUTPUT_NORMAL, "]\n");

    control->Output(DEBUG_OUTPUT_NORMAL, "\n");

    // done!
    //
    hRes = S_OK;

    cleanup:
    ReleaseInterfaces();
    return hRes;
}

